#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Usage: cpm <package-name> [-k N] [-p|-f|-s]"
    exit 1
fi

PKG=$1
shift

K=""
SUFFIX=""

while [[ $# -gt 0 ]]; do
    case $1 in
        -k) K=$2; shift 2 ;;
        -p) SUFFIX="Pkgfile"; shift ;;
        -f) SUFFIX=".footprint"; shift ;;
        -s) SUFFIX=".signature"; shift ;;
        *) shift ;;
    esac
done

RAW=$(curl -s -A "Mozilla/5.0" "https://crux.nu/portdb/?a=search&q=$PKG")

eval "$(echo "$RAW" | awk '
/<table class="listing">/,/<\/table>/ {
    if (/<td>/) {
        gsub(/<[^>]*>/, "")
        gsub(/&nbsp;/, " ")
        gsub(/^[ \t]+|[ \t]+$/, "")
        if (length > 0 && !/^P F S/ && !/rsync/ && !/httpup/) {
            data[++c] = $0
        }
    }
    if (/httpup sync|rsync -aqz/) {
        gsub(/<[^>]*>/, "")
        gsub(/&quot;/, "")
        gsub(/^[ \t]+|[ \t]+$/, "")
        if (match($0, /(httpup sync [^ ]+ [^ ]+)/, m) || match($0, /(rsync -aqz [^ ]+ [^ ]+)/, m)) {
            cmd[++d] = m[1]
        }
    }
}
END {
    row = 1
    for (i = 1; i <= c; i += 2) {
        if (i + 1 <= c) {
            printf "ports[%d]=\"%s\"\ncols[%d]=\"%s\"\ncmds[%d]=\"%s\"\n", row, data[i], row, data[i+1], row, (row <= d) ? cmd[row] : ""
            row++
        }
    }
}')"

if [[ -n "$K" && -n "$SUFFIX" ]]; then
    raw_cmd="${cmds[$K]}"
    if [[ "$raw_cmd" == httpup* ]]; then
        base=$(echo "$raw_cmd" | grep -oP 'https?://[^#]+')
        pkg=$(echo "$raw_cmd" | grep -oP '#\K\S+')
        url="${base%/}/${pkg}/${SUFFIX}"
    elif [[ "$raw_cmd" == rsync* ]]; then
        path=$(echo "$raw_cmd" | grep -oP 'crux\.nu::\S+')
        url="https://crux.nu/ports/${path#*crux.nu::ports/}${SUFFIX}"
    fi
    curl -s "$url"
    exit 0
fi

printf "%-4s %-30s %-20s\n" "NUM" "PORT" "COLLECTION"
for i in "${!ports[@]}"; do
    printf "%-4s %-30s %-20s \n%s\n\n" "$i" "${ports[$i]}" "${cols[$i]}" "bash -c '${cmds[$i]}'"
done

