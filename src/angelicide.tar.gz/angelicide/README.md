# Angelicide Window Manager

**angelicide** is a highly customizable, source-driven window manager built with [penrose](https://github.com/sminez/penrose) for X11. Written in Rust, it embraces a philosophy of "configuration through compilation" — where your window manager's behavior is defined directly in the source code.

## Philosophy

Unlike traditional "suckless" tools that use config.h headers, angelicide takes minimalism a step further. There's no separate configuration file to edit, no headers to regenerate, no dynamic configuration at all. Your window manager **is** the source code. Every keybinding, every color, every behavior is defined directly in Rust, giving you:

- **True minimalism**: No runtime configuration parsing, no overhead
- **Compile-time guarantees**: If it compiles, it works (no runtime config errors)
- **Unlimited flexibility**: Not limited by what a config format can express
- **Rust's safety and performance**: Zero-cost abstractions, memory safety, and blazing speed

## Features

- **Full Rust configuration**: Edit `src/main.rs`, run `cargo build --release` and `./install.sh', restart
- **Pure X11**: Built on penrose with x11rb backend
- **Essential keybindings**:
  - `Super + Return` — Launch terminal (alacritty)
  - `Super + j/k` — Focus next/previous window
  - `Super + Shift + j/k` — Swap windows
  - `Super + h/l` — Shrink/expand main area
  - `Super + Space` — Toggle floating mode
  - `Super + f` — Toggle fullscreen
  - `Super + 1-9` — Switch tags
  - `Super + Shift + 1-9` — Move window to tag
  - `Super + q` — Close focused window
  - `Super + Shift + q` — Exit (pkill X)
- **Customizable bar** (optional) with:
  - Workspace indicators
  - Current layout
  - Active window name
  - Clock
- **Scratchpad support** in next commit

## Building from source

```bash
hg clone https://hg.sr.ht/~umix11/angelicide
cd angelicide
cargo build
./install.sh # change doas on sudo if you use it
```

## Configuration

Edit `src/main.rs`. This is your config file. The constants at the top control the basic appearance:

```rust
// Terminal
pub const TERM: &str = "alacritty";

// Colors (ARGB hex)
pub const FOCUSED: u32 = 0xa18fafff;
pub const UNFOCUSED: u32 = 0x909090ff;

// Bar settings
pub const BAR: bool = true;  // Set to false to disable the bar
pub const BAR_HEIGHT_PX: u32 = 15;
```

Want to change keybindings? Modify `raw_key_bindings()`. Want different layouts? Edit `layouts()`. The entire window manager is yours to mold.

## Requirements

- X11 server
- Rust and Cargo (install via [rustup](https://rustup.rs/))
- xmodmap (for keybindings parsing)
- A terminal (alacritty by default)

## Why "Angelicide"?

The name evokes the idea of "killing angels" — challenging the notion that minimalism requires compromise. Angelicide proves you can have both minimalism AND expressiveness, both simplicity AND power, both purity AND practicality.

## License

Do what you want with it
