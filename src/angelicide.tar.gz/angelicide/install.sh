#!/bin/bash
path=/usr/local/bin/

cargo build

if [ -f "target/debug/angelicide" ]; then
    doas rm -f "$path/angelicide"
    doas cp target/debug/angelicide "$path/angelicide"
    echo "ok"
else
    echo "error: no file"
    exit 1
fi
