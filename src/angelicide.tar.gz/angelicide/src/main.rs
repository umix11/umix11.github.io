use penrose::x11rb::RustConn;
use penrose::{
    builtin::{
        actions::{
            exit,
            modify_with, send_layout_message, spawn,
            floating::{toggle_floating_focused, MouseDragHandler, MouseResizeHandler},
        },
        hooks::SpacingHook,
        layout::{messages::{ExpandMain, ShrinkMain}, MainAndStack},
    },
    core::{
        Config, WindowManager,
        bindings::{
            KeyEventHandler, MouseEventHandler, MouseState,
            parse_keybindings_with_xmodmap,
        },
        layout::LayoutStack,
    },
    extensions::{
    	hooks::add_ewmh_hooks,
        actions::toggle_fullscreen,
    },
    Color,
    map,
    stack,
};

use penrose_ui::{
    StatusBar, TextStyle,
    bar::widgets::{
        Workspaces, CurrentLayout, ActiveWindowName, IntervalText,
    },
    Position,
};

use std::collections::HashMap;
use std::time::Duration;

/* ================== CONFIG =============== */
// Terminal
pub const TERM: &str = "alacritty";

// Borders
pub const FOCUSED: u32 = 0xa18fafff;
pub const UNFOCUSED: u32 = 0x909090ff;

// Bar settings
pub const FONT: &str = "Hermit";
pub const FONT_SIZE: u8 = 8;
pub const BAR_HEIGHT_PX: u32 = 15;
pub const BG: u32 = 0xffffffff;
pub const FG: u32 = 0x000000ff;
pub const ACTIVE_BG: u32 = 0xa18fafff;
pub const BAR: bool = true;

// Gaps
pub const INGAP_PX: u32 = 10;
pub const OUTGAP_PX: u32 = 10;
pub const TOP_PX: u32 = if BAR { BAR_HEIGHT_PX } else { 0 };
pub const BOTTOM_PX: u32 = 0;
/* ========================================= */


/* ================= BINDS ================= */
fn raw_key_bindings() -> HashMap<String, Box<dyn KeyEventHandler<RustConn>>> {
    let mut raw_bindings = map! {
        map_keys: |k: &str| k.to_string();

        "M-j" => modify_with(|cs| cs.focus_down()),
        "M-k" => modify_with(|cs| cs.focus_up()),
        "M-S-j" => modify_with(|cs| cs.swap_down()),
        "M-S-k" => modify_with(|cs| cs.swap_up()),
        "M-l" => send_layout_message(|| ExpandMain),
        "M-h" => send_layout_message(|| ShrinkMain),
        "M-q" => modify_with(|cs| cs.kill_focused()),
        "M-Tab" => modify_with(|cs| cs.next_layout()),
        "M-S-Return" => modify_with(|cs| cs.rotate_focus_to_head()),
        "M-space" => toggle_floating_focused(), 
        "M-f" => toggle_fullscreen(),
        "M-s" => spawn("sshot"),
        "M-p" => spawn("cmenu-run"),
        "M-w" => spawn("firefox"),
        "M-Return" => spawn(TERM),
		"M-S-q" => spawn("pkill x"),
		"M-F12" => spawn("powermenu"),
        "M-r" => exit(),
    };

    for tag in &["1", "2", "3", "4", "5", "6", "7", "8", "9"] {
        raw_bindings.extend([
            (
                format!("M-{tag}"),
                modify_with(move |client_set| client_set.focus_tag(tag)),
            ),
            (
                format!("M-S-{tag}"),
                modify_with(move |client_set| client_set.move_focused_to_tag(tag)),
            ),
        ]);
    }

    raw_bindings
}

pub fn mouse_bindings() -> HashMap<MouseState, Box<dyn MouseEventHandler<RustConn>>> {
    use penrose::core::bindings::{
        ModifierKey::Meta,
        MouseButton::{Left, Right},
    };

    map! {
        map_keys: |(button, modifiers)| MouseState { button, modifiers };

        (Left, vec![Meta]) => MouseDragHandler::boxed_default(),
        (Right, vec![Meta]) => MouseResizeHandler::boxed_default(),
    }
}

/* ========================================= */

/* ============== LAYOUTS ================== */
pub fn layouts() -> LayoutStack {
	const MAX_MAIN: u32 = 1;
	const RATIO: f32 = 0.5;
	const RATIO_STEP: f32 = 0.05;
    stack!(
        MainAndStack::side(MAX_MAIN, RATIO, RATIO_STEP),
        MainAndStack::side_mirrored(MAX_MAIN, RATIO, RATIO_STEP)
    )
}
/* ========================================= */

/* ============= STATUS BAR ================ */
fn create_status_bar<X: penrose::x::XConn + 'static>(position: Position) -> penrose_ui::Result<StatusBar<X>> {
    let bg_color: Color = BG.into();
    let fg_color: Color = FG.into();
    let active_color: Color = ACTIVE_BG.into();

    let time_style = TextStyle {
        fg: fg_color,
        bg: Some(bg_color),
        padding: (8, 4),
    };

    StatusBar::try_new(
        position,
        BAR_HEIGHT_PX,
        bg_color,
        FONT,
        FONT_SIZE,
        vec![
		    Box::new(Workspaces::new(
                TextStyle {
                    fg: fg_color,
                    bg: Some(bg_color),
                    padding: (10, 10),
                },
                active_color,
                fg_color,             
            )),
            
            Box::new(CurrentLayout::new(
                TextStyle {
                    fg: fg_color,
                    bg: Some(bg_color),
                    padding: (8, 4),
                },
            )),

            Box::new(ActiveWindowName::new(
                50,
                TextStyle {
                    fg: fg_color,
                    bg: Some(active_color),
                    padding: (10, 10),
                },
                true,
                false,
            )),

			Box::new(IntervalText::new(
                time_style.clone(),
                || Some(format!("{}", chrono::Local::now().format("%A %d | %H:%M"))),
                Duration::from_secs(1),
                false,
                false,
            )),
        ],
    )
}
/* ========================================= */

fn main() -> anyhow::Result<()> {
    let conn = RustConn::new()?;
    
    let layout_hook = Box::new(SpacingHook {
        inner_px: INGAP_PX,
        outer_px: OUTGAP_PX,
        top_px: TOP_PX,
        bottom_px: BOTTOM_PX,
    });
    
    let config = add_ewmh_hooks(Config {
        border_width: 5,
        normal_border: UNFOCUSED.into(),
        focused_border: FOCUSED.into(),
        default_layouts: layouts(),
        layout_hook: Some(layout_hook),
        ..Config::default()
    });
    
    let key_bindings = parse_keybindings_with_xmodmap(raw_key_bindings())?;
    let bar = create_status_bar(Position::Top)?;
    let mut wm = WindowManager::new(config, key_bindings, mouse_bindings(), conn)?;
    if BAR {
    	wm = bar.add_to(wm);
   	}

    wm.run()?;
    Ok(())
}
