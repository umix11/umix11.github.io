# 5element

**My fork of [rdap/rio](https://github.com/rdap/rio)**

A unique X11 window manager featuring an **infinite scrollable viewport** instead of traditional workspaces. Based on rio/9wm, reimagined for modern workflows.

## What Makes 5element Different?

### Infinite Scrollable Viewport
Unlike traditional window managers with fixed workspaces, 5element provides an **infinite 2D canvas** where you can organize windows freely. Think of it as Photoshop's canvas for your desktop - pan around with Super+LeftClick and place windows anywhere in infinite space.

### No Automatic Window Placement
Windows don't pop up randomly. You **manually draw** where each window should be with your mouse - giving you precise control over your layout from the start.

### Photoshop-Style Panning
Hold **Super+LeftClick** anywhere and drag to pan your viewport. Works everywhere - over windows, empty space, doesn't matter. Your entire desktop becomes a draggable canvas.

### Rio-Inspired Workflow
Inherited from Plan 9's rio:
- **Manual window placement** - draw windows where you want them
- **Focus follow mouse** by default (configurable)
- **Simple, minimal chrome** - thin borders, no title bars
- **Hold mode** - lock windows in place

## Installation

### Dependencies
```bash
# Arch Linux
sudo pacman -S base-devel libx11 libxext libxft

# Debian/Ubuntu
sudo apt install build-essential libx11-dev libxext-dev libxft-dev

# Void Linux
sudo xbps-install base-devel libX11-devel libXext-devel libXft-devel
```

### Building
```bash
hg clone https://hg.sr.ht/~umix11/5element
cd 5element
mk
doas ./install.sh
```

### Starting
Add to your `.xinitrc`:
```bash
exec 5element
```

## Basic Usage

### Spawning Windows

**Method 1: Click and drag**
1. Click on empty space (default: left mouse button)
2. Drag to draw a rectangle
3. Release - terminal spawns in that area

**Method 2: From menu**
1. Right-click on empty space
2. Select application from menu
3. Draw where you want it

### Moving Around

**Viewport Panning**
- Hold `Super+LeftClick` anywhere
- Drag mouse to pan the viewport
- Works over windows, empty space, everything

**Window Management**
- **Move window**: Drag window border with right mouse button
- **Resize window**: Drag window border with left mouse button  
- **Corner resize**: Drag corner with middle mouse button
- **Fullscreen**: `Super+F` (toggle)
- **Window switching**: `Super+Tab`

### The Menu

Right-click on empty space to open the menu:

```
@new      - Launch dmenu (application launcher)
@term     - Spawn terminal
@hide     - Hide current window
@move     - Move window
@resize   - Resize window
@delete   - Close window
@tile     - Tile all visible windows
```

Custom applications can be added in `config.h`.

## Configuration

All configuration is done in `config.h`. After editing, recompile:
```bash
make clean && make
sudo make install
```

### Common Customizations

#### Change Viewport Panning Controls

Default is `Super+LeftClick`. To change to `Alt+RightClick`:

```c
#define PAN_BUTTON   Button3   /* Right button */
#define PAN_MOD      Mod1Mask  /* Alt key */
```

#### Change Colors

```c
/* Active window borders */
#define ACTIVE_BORDER_COLOR    0xFF0000  /* Red */
#define ACTIVE_INNER_BORDER_COLOR   0x00FF00  /* Green */

/* Inactive window borders */
#define INACTIVE_BORDER_COLOR  0x808080  /* Gray */
```

Colors are in hexadecimal RGB format: `0xRRGGBB`

#### Add Custom Keybindings

```c
#define CUSTOM_KEYS \
    { Mod4Mask, XK_Return, TERMINAL }, \
    { Mod4Mask, XK_d, "dmenu_run" }, \
    { Mod4Mask, XK_b, "firefox" }, \
    { Mod4Mask|ShiftMask, XK_q, "poweroff" },
```

**Modifiers:**
- `Mod1Mask` = Alt
- `Mod4Mask` = Super/Windows key
- `ShiftMask` = Shift
- `ControlMask` = Control
- Combine with `|`: `Mod4Mask|ShiftMask`

**Keys:**
- Letters: `XK_a` through `XK_z`
- Numbers: `XK_0` through `XK_9`
- Special: `XK_Return`, `XK_space`, `XK_Tab`
- Function: `XK_F1` through `XK_F12`

See `/usr/include/X11/keysymdef.h` for all key symbols.

#### Change Default Terminal

```c
#define TERMINAL "alacritty"  /* or "kitty", "st", "xterm", etc */
```

#### Modify Menu Items

```c
#define MENU_ITEMS { \
    "@new", \
    "@term", \
    "firefox", \
    "spotify", \
    "thunar:thunar", \
    "@hide", \
    "@delete", \
    NULL \
}
```

Format: `"label:command"` or just `"command"`

### Advanced Configuration

#### Focus Behavior

```c
/* 0 = click to focus, 1 = focus follows mouse */
#define FFM 0
```

#### Border Sizes

```c
#define BORDER   5  /* Outer border width */
#define INNER_BORDER  5  /* Inner border width */
```

#### Mouse Button Bindings

```c
/* On empty space */
#define SPAWN_ACTIVATE_BUTTON  Button1  /* Left click spawns window */
#define MAIN_MENU_BUTTON       Button3  /* Right click opens menu */

/* On window borders */
#define BORDER_RESIZE_BUTTON   Button1  /* Left drag resizes */
#define BORDER_MOVE_BUTTON     Button3  /* Right drag moves */
#define BORDER_PULL_BUTTON     Button2  /* Middle drag corner resize */
```

## Workflow Tips

### Organizing Your Space

**Mental Model**: Think of your desktop as an infinite grid
- **Center area**: Active work (terminals, editors, browsers)
- **Left**: Communication apps (Discord, Slack)  
- **Right**: Media (Spotify, video players)
- **Top**: Documentation and references
- **Bottom**: System monitors and terminals

**Navigation**: Use Super+LeftClick drag liberally. Don't be afraid to pan around - your windows stay exactly where you left them in world space.

### Window Management Patterns

**Stacking Windows**: Place windows on top of each other in world space, use Super+Tab to cycle through them without moving.

**Temporary Windows**: Spawn throwaway terminals far from your main workspace, pan there when needed, close when done.

**Reference Windows**: Keep documentation windows "off to the side" in world space, pan to them when you need to check something.

### Tiling

While 5element is primarily a manual window manager, you can tile all visible windows:
1. Arrange windows roughly where you want them
2. Right-click → `@tile`
3. Windows in the current viewport get tiled

Tiling only affects windows currently visible on screen.

## Comparison to Other WMs

| Feature | 5element | i3/bspwm | dwm | awesome |
|---------|----------|----------|-----|---------|
| Window placement | Manual (rio-style) | Auto | Auto | Auto |
| Workspaces | Infinite viewport | Fixed numbered | Tags | Fixed numbered |
| Navigation | Pan like Photoshop | Keyboard workspace switch | Keyboard | Keyboard |
| Configuration | config.h (recompile) | Text config | config.h | Lua config |
| Tiling | Optional | Primary | Primary | Primary |

**Use 5element if:**
- You want **precise control** over window placement
- You think in **spatial layouts** rather than workspace numbers
- You like **manually arranging** windows with your mouse
- You want a **minimalist** setup that gets out of your way

**Don't use 5element if:**
- You prefer **automatic tiling**
- You want **keyboard-only** workflow
- You like **traditional workspaces** with fixed numbers
- You need **heavy runtime configuration** without recompiling

## Troubleshooting

### Windows spawn in wrong location
Make sure you're **drawing the spawn area** with your mouse. 5element doesn't auto-place windows - you must drag out a rectangle where you want the window to appear.

### Can't move viewport
Check that your panning keybind isn't conflicting:
- Default is `Super+LeftClick`
- Make sure another program isn't grabbing this combo
- Try changing `PAN_BUTTON` or `PAN_MOD` in config.h

### Viewport panning is too sensitive
Currently panning is 1:1 with mouse movement. If you want slower panning, you'll need to modify the `scroll_viewport()` function in `client.c` to scale the delta values.

### Menu doesn't appear
- Right-click on **empty space** (not on a window)
- Check that `MAIN_MENU_BUTTON` is set correctly in config.h
- Make sure `MENU_ITEMS` array ends with `NULL`

### Custom keybinding not working
- Verify the key symbol is correct (check `/usr/include/X11/keysymdef.h`)
- Make sure modifiers are correct (`Mod4Mask` for Super)
- Recompile after editing config.h: `make clean && make`
- Check for syntax errors in the `CUSTOM_KEYS` array

## Philosophy

5element embraces **manual spatial organization**. Your desktop is a canvas, windows are objects you place deliberately. The infinite viewport means you never run out of space - organize in 2D however makes sense to you.

This isn't for everyone. If you like automatic tiling and keyboard-driven workflows, try catwm or ratpoison. But if you think in spatial layouts and want precise control over every window's position, 5element might be your new home.

## Credits

Based on:
- **rio** - Plan 9's window manager
- **9wm** - David Hogan's port to X11
- Various rio forks and experiments

Created because traditional workspace-based WMs feel limiting when you think in spatial layouts.

## License

Do what you want

## Contributing

Pull requests welcome! Particularly interested in:
- Better documentation
- Bug fixes
- Performance improvements
- Feature additions that preserve the core philosophy

Please open an issue before starting major work.

---

**Made for people who think in space, not in numbered workspaces.**
