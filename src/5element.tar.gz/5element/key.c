/* Copyright (c) 2005 Russ Cox, see README for licence details */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <X11/X.h>
#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <X11/extensions/shape.h>
#include "dat.h"
#include "fns.h"
#include "config.h"

static void alttab(int shift);

/* Custom key binding structure */
typedef struct {
    unsigned int mod;
    KeySym keysym;
    const char *cmd;
} Key;

/* Custom key bindings from config.h */
static Key customkeys[] = {
#ifdef CUSTOM_KEYS
    CUSTOM_KEYS
#endif
};

void
keysetup(void)
{
    int i, j;
    int tabcode = XKeysymToKeycode(dpy, ALT_TAB_KEY);
    int fullscreencode = XKeysymToKeycode(dpy, FULLSCREEN_KEY);
    int homecode = XKeysymToKeycode(dpy, CENTER_ON_HOME_KEY);
    int wincode = XKeysymToKeycode(dpy, CENTER_ON_WIN_KEY);

    for(i=0; i<num_screens; i++){
        /* Window switching */
        XGrabKey(dpy, tabcode, ALT_TAB_MOD, screens[i].root, 0, GrabModeSync, GrabModeAsync);
        XGrabKey(dpy, tabcode, ALT_TAB_MOD|ShiftMask, screens[i].root, 0, GrabModeSync, GrabModeAsync);
        
        /* Fullscreen */
        XGrabKey(dpy, fullscreencode, FULLSCREEN_MOD, screens[i].root, 0, GrabModeSync, GrabModeAsync);
        
        /* Camera centering */
        XGrabKey(dpy, homecode, CENTER_ON_HOME_MOD, screens[i].root, 0, GrabModeSync, GrabModeAsync);
        XGrabKey(dpy, wincode, CENTER_ON_WIN_MOD, screens[i].root, 0, GrabModeSync, GrabModeAsync);

        /* Register custom key bindings */
        for(j = 0; j < sizeof(customkeys)/sizeof(customkeys[0]); j++){
            int code = XKeysymToKeycode(dpy, customkeys[j].keysym);
            if(code != 0) {
                XGrabKey(dpy, code, customkeys[j].mod, screens[i].root, 1, GrabModeSync, GrabModeAsync);
            }
        }
    }
}

void
keypress(XKeyEvent *e)
{
    KeySym keysym = XLookupKeysym(e, 0);
    int tabcode = XKeysymToKeycode(dpy, ALT_TAB_KEY);
    int fullscreencode = XKeysymToKeycode(dpy, FULLSCREEN_KEY);
    int homecode = XKeysymToKeycode(dpy, CENTER_ON_HOME_KEY);
    int wincode = XKeysymToKeycode(dpy, CENTER_ON_WIN_KEY);
    int i;
    
    unsigned int modmask = ShiftMask | ControlMask | Mod1Mask | Mod4Mask;
    
    /* Camera centering - home position */
    if(e->keycode == homecode && (e->state & modmask) == CENTER_ON_HOME_MOD) {
        ScreenInfo *s = getscreen(e->root);
        if(s) {
            center_camera_on_origin(s);
        }
        XAllowEvents(dpy, SyncKeyboard, e->time);
        return;
    }
    /* Camera centering - active window */
    else if(e->keycode == wincode && (e->state & modmask) == CENTER_ON_WIN_MOD) {
        if(current) {
            center_camera_on_current();
        }
        XAllowEvents(dpy, SyncKeyboard, e->time);
        return;
    }
    /* Fullscreen toggle */
    else if(e->keycode == fullscreencode && (e->state & modmask) == FULLSCREEN_MOD && current) {
        ScreenInfo *s = getscreen(DefaultRootWindow(dpy));
        maximize(current, s);
        XAllowEvents(dpy, SyncKeyboard, e->time);
        return;
    }
    /* Window switching */
    else if(e->keycode == tabcode && (e->state & modmask) == ALT_TAB_MOD) {
        alttab(e->state & ShiftMask);
        XAllowEvents(dpy, SyncKeyboard, e->time);
        return;
    }
    
    /* Check custom key bindings */
    for(i = 0; i < sizeof(customkeys)/sizeof(customkeys[0]); i++){
        if(keysym == customkeys[i].keysym && 
           (e->state & modmask) == (customkeys[i].mod & modmask)){
            ScreenInfo *s = getscreen(e->root);
            if(s && fork() == 0){
                if(dpy)
                    close(ConnectionNumber(dpy));
                if(s->display[0] != '\0')
                    putenv(s->display);
                signal(SIGINT, SIG_DFL);
                signal(SIGTERM, SIG_DFL);
                signal(SIGHUP, SIG_DFL);
                setsid();
                execl(shell, shell, "-c", customkeys[i].cmd, NULL);
                fprintf(stderr, "5element: exec %s -c %s", shell, customkeys[i].cmd);
                perror(" failed");
                exit(1);
            }
            XAllowEvents(dpy, SyncKeyboard, e->time);
            return;
        }
    }
    
    XAllowEvents(dpy, SyncKeyboard, e->time);
}

void
keyrelease(XKeyEvent *e)
{
    XAllowEvents(dpy, SyncKeyboard, e->time);
}

static void
alttab(int shift)
{
    Client *prevcurrent;
    
    prevcurrent = current;
    shuffle(shift);
    
     if(current && current != prevcurrent){
        XRaiseWindow(dpy, current->parent);
        XRaiseWindow(dpy, current->window);
        XSetInputFocus(dpy, current->window, RevertToPointerRoot, CurrentTime);
    }
	center_camera_on_current();
}
