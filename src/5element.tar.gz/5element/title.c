/* Title bar support for 5element */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include "dat.h"
#include "fns.h"
#include "config.h"

#if TITLEBARS

extern XFontStruct *title_font;

static Atom wm_name_atom = None;
static Atom net_wm_name_atom = None;

static void
init_title_atoms(void)
{
    if(wm_name_atom == None)
        wm_name_atom = XInternAtom(dpy, "WM_NAME", False);
    if(net_wm_name_atom == None)
        net_wm_name_atom = XInternAtom(dpy, "_NET_WM_NAME", False);
}

void
draw_title(Client *c, int active)
{
    unsigned long title_color, text_color;
    XGCValues gv;
    GC gc;

    if(c == NULL || c->parent == c->screen->root)
        return;

    if(active) {
        title_color = colorpixel(dpy, c->screen, c->screen->depth,
                                 TITLE_ACTIVE_COLOR, c->screen->black);
        text_color = colorpixel(dpy, c->screen, c->screen->depth,
                                TITLE_TEXT_ACTIVE_COLOR, c->screen->white);
    } else {
        title_color = colorpixel(dpy, c->screen, c->screen->depth,
                                 TITLE_INACTIVE_COLOR, c->screen->white);
        text_color = colorpixel(dpy, c->screen, c->screen->depth,
                                TITLE_TEXT_INACTIVE_COLOR, c->screen->black);
    }

    gv.foreground = title_color;
    gv.background = title_color;

    if(title_font) {
        gv.font = title_font->fid;
        gc = XCreateGC(dpy, c->parent,
                       GCForeground|GCBackground|GCFont, &gv);
    } else {
        gc = XCreateGC(dpy, c->parent,
                       GCForeground|GCBackground, &gv);
    }

    XFillRectangle(dpy, c->parent, gc,
                   BORDER, BORDER,
                   c->dx + 2*INNER_BORDER, TITLEHEIGHT);

#if TITLE_TEXT
    if(c->label && title_font && strlen(c->label) > 0) {
        gv.foreground = text_color;
        gv.background = title_color;
        XChangeGC(dpy, gc, GCForeground|GCBackground, &gv);

        char *display_text = c->label;
        char truncated[256];
        int char_width = title_font->max_bounds.width ?
                         title_font->max_bounds.width : 8;
        int max_chars = (c->dx - 20) / char_width;

        if(max_chars > 3 &&
           (int)strlen(c->label) > max_chars) {
            int copy_len = max_chars - 3;
            if(copy_len > 255)
                copy_len = 255;
            strncpy(truncated, c->label, copy_len);
            truncated[copy_len] = '\0';
            strcat(truncated, "...");
            display_text = truncated;
        }

        XDrawString(dpy, c->parent, gc,
                    BORDER + 6,
                    BORDER + TITLEHEIGHT/2 + title_font->ascent/2,
                    display_text,
                    strlen(display_text));
    }
#endif

#if CLOSEBUTTON
    {
        int button_size = CLOSE_BUTTON_SIZE;
        int button_x = BORDER + c->dx + 2*INNER_BORDER - button_size - 8;
        int button_y = BORDER + (TITLEHEIGHT - button_size) / 2;

        unsigned long close_color =
            colorpixel(dpy, c->screen, c->screen->depth,
                       active ?
                       TITLE_CLOSE_ACTIVE_COLOR :
                       TITLE_CLOSE_INACTIVE_COLOR,
                       c->screen->black);

        gv.foreground = close_color;
        gv.line_width = 3;
        gv.cap_style = CapRound;
        gv.join_style = JoinRound;

        XChangeGC(dpy, gc,
                  GCForeground | GCLineWidth |
                  GCCapStyle | GCJoinStyle,
                  &gv);

        XDrawLine(dpy, c->parent, gc,
                  button_x, button_y,
                  button_x + button_size,
                  button_y + button_size);

        XDrawLine(dpy, c->parent, gc,
                  button_x,
                  button_y + button_size,
                  button_x + button_size,
                  button_y);
    }
#endif

    XFreeGC(dpy, gc);
}

void
update_title(Client *c)
{
    XTextProperty prop;
    char **list = NULL;
    int count;
    char *new_label = NULL;

    if(c == NULL)
        return;

    init_title_atoms();

    if(XGetTextProperty(dpy, c->window,
                        &prop, net_wm_name_atom)
       && prop.value) {

        if(prop.encoding == XA_STRING) {
            new_label = strdup((char*)prop.value);
        } else if(XmbTextPropertyToTextList(dpy,
                    &prop, &list, &count) == Success) {
            if(count > 0 && list && list[0])
                new_label = strdup(list[0]);
            if(list)
                XFreeStringList(list);
        }
        XFree(prop.value);
    }

    if(new_label == NULL &&
       XGetTextProperty(dpy, c->window,
                        &prop, wm_name_atom)
       && prop.value) {

        if(prop.encoding == XA_STRING) {
            new_label = strdup((char*)prop.value);
        } else if(XmbTextPropertyToTextList(dpy,
                    &prop, &list, &count) == Success) {
            if(count > 0 && list && list[0])
                new_label = strdup(list[0]);
            if(list)
                XFreeStringList(list);
        }
        XFree(prop.value);
    }

    if(new_label == NULL)
        new_label = strdup("5element");

    if(c->label)
        free(c->label);

    c->label = new_label;

    XClearArea(dpy, c->parent,
               BORDER, BORDER,
               c->dx + 2*INNER_BORDER,
               TITLEHEIGHT,
               True);
}

void
select_title_events(Client *c)
{
    if(c == NULL)
        return;

    XSelectInput(dpy, c->window,
                 StructureNotifyMask |
                 PropertyChangeMask);
}

int
intitle(Client *c, int x, int y)
{
    if(c == NULL ||
       c->parent == c->screen->root)
        return 0;

    if(x >= BORDER &&
       x < BORDER + c->dx + 2*INNER_BORDER &&
       y >= BORDER &&
       y < BORDER + TITLEHEIGHT)
        return 1;

    return 0;
}

int
inclosebutton(Client *c, int x, int y)
{
    int button_size = 12;
    int padding = 4;
    int button_x, button_y;

    if(!intitle(c, x, y))
        return 0;

    button_x = BORDER + c->dx + 2*INNER_BORDER
               - button_size - 8;
    button_y = BORDER +
               (TITLEHEIGHT - button_size) / 2;

    if(x >= button_x - padding &&
       x < button_x + button_size + padding &&
       y >= button_y - padding &&
       y < button_y + button_size + padding)
        return 1;

    return 0;
}

#endif
