/* Copyright (c) 1994-1996 David Hogan, see README for licence details */
#include <X11/Xutil.h>

#define CORNER		_corner
#define	INSET		_inset
#define MAXHIDDEN	128
#define B3FIXED 	5

#define AllButtonMask	(Button1Mask|Button2Mask|Button3Mask \
			|Button4Mask|Button5Mask)
#define ButtonMask	(ButtonPressMask|ButtonReleaseMask)
#define MenuMask	(ButtonMask|ButtonMotionMask|ExposureMask)
#define MenuGrabMask	(ButtonMask|ButtonMotionMask|StructureNotifyMask)

#ifdef	Plan9
#define DEFSHELL	"/bin/rc"
#else
#define DEFSHELL	"/bin/sh"
#endif

typedef struct Client Client;
typedef struct Menu Menu;
typedef struct ScreenInfo ScreenInfo;

struct Client {
	Window		window;
	Window		parent;
	Window		parent2;
	Window		trans;
	Client		*next;
	Client		*revert;

	int 		x;
	int 		y;
	int 		dx;
	int 		dy;
	int 		border;

	XSizeHints	size;
	int 		min_dx;
	int 		min_dy;

	int 		state;
	int 		init;
	int 		reparenting;
	int 		is9term;
	int 		proto;

	char		*label;
	char		*instance;
	char		*class;
	char		*name;
	char		*iconname;

	Colormap	cmap;
	int 		ncmapwins;
	Window		*cmapwins;
	Colormap	*wmcmaps;
	ScreenInfo	*screen;
	int ismaximized;
	int pre_x, pre_y, pre_dx, pre_dy;

	/* For scrollable viewport */
	int sticky;
};

#define hidden(c)	((c)->state == IconicState)
#define withdrawn(c)	((c)->state == WithdrawnState)
#define normal(c)	((c)->state == NormalState)

#define Pdelete 	1
#define Ptakefocus	2

struct Menu {
	char	**item;
	char	*(*gen)();
	int	lasthit;
};

enum BorderOrient {
	BorderUnknown = 0,
	BorderN,
	BorderNNE,
	BorderENE,
	BorderE,
	BorderESE,
	BorderSSE,
	BorderS,
	BorderSSW,
	BorderWSW,
	BorderW,
	BorderWNW,
	BorderNNW,
	NBorder
};
typedef enum BorderOrient BorderOrient;

struct ScreenInfo {
        Window selectwin;
        GC gcxor;
	int			num;
	int			depth;
	Visual		*vis;
	int			width;
	int			height;
	Window		root;
	Window		menuwin;
	Window		sweepwin;
	Colormap		def_cmap;
	GC			gc;
	GC			gccopy;
	GC			gcred;
	GC			gcsweep;
	GC			gcmenubg;
	GC			gcmenubgs;
	GC			gcmenufg;
	GC			gcmenufgs;
	unsigned long	black;
	unsigned long	white;
	unsigned long	activeborder;
	unsigned long	inactiveborder;
	unsigned long	activeborder2;
	unsigned long	inactiveborder2;
	Pixmap		bkup[2];
	int			min_cmaps;
	Cursor		target;
	Cursor		sweep0;
	Cursor		boxcurs;
	Cursor		arrow;
	Cursor		bordcurs[NBorder];
	Pixmap		root_pixmap;
	char			display[256];

	/* Scrollable viewport */
	int scroll_x;
	int scroll_y;
};

extern Display		*dpy;
extern ScreenInfo	*screens;
extern int			num_screens;
extern int			initting;
extern XFontStruct	*font;
extern char		**myargv;
extern Bool 		shape;
extern char 		*shell;
extern char 		*version[];
extern int			_corner;
extern int			_inset;
extern int			curtime;
extern int			debug;
extern int			solidsweep;
extern int			ffm;

extern Atom		exit_5element;
extern Atom		restart_5element;
extern Atom 		wm_state;
extern Atom		wm_change_state;
extern Atom 		wm_protocols;
extern Atom 		wm_delete;
extern Atom 		wm_take_focus;
extern Atom 		wm_colormaps;
extern Atom		wm_state_fullscreen;
extern Atom		wm_state;

extern Client		*clients;
extern Client		*current;

extern Client		*hiddenc[];
extern int 			numhidden;
extern char 		*b3items[];
extern Menu 		b3menu;

extern int			isNew;
extern int 			ignore_badwindow;
extern int			requirePosition;

/* Panning globals */
extern int panning;
extern int pan_start_x;
extern int pan_start_y;
extern int pan_start_scroll_x;
extern int pan_start_scroll_y;

/* Custom menu support */
extern char *menu_items[];

enum {
    MENU_SHELL,
    MENU_FUNC,
    MENU_SEPARATOR,
    MENU_LABEL,
    MENU_WORKSPACE
};

struct MenuItem {
    char *label;
    int type;
    union {
        char *cmd;
        int wsn;
        void (*func)(Client*, ScreenInfo*);
    } action;
};

extern struct MenuItem **dynmenu_items;
extern int dynmenu_count;

void initdynmenu(void);
void execmenuitem(int n, Client *c, ScreenInfo *s);
void build_dynmenu(void);

void maximize(Client*, ScreenInfo*);
void tile_windows(ScreenInfo *s);
void tile_windows_layout(ScreenInfo *s, int layout);

void scroll_viewport(ScreenInfo *s, int delta_x, int delta_y);
void apply_scroll_to_windows(ScreenInfo *s);
int get_screen_x(ScreenInfo *s, int world_x);
int get_screen_y(ScreenInfo *s, int world_y);
int get_world_x(ScreenInfo *s, int screen_x);
int get_world_y(ScreenInfo *s, int screen_y);
void autostart(void);
