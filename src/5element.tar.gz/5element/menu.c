/*
 * Pop-up menus with custom menu support and scroll viewport.
 */

#define _SVID_SOURCE 1
#define _DEFAULT_SOURCE 1
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include "dat.h"
#include "fns.h"
#include "config.h"

extern int requirePosition;

Client *hiddenc[MAXHIDDEN];
int numhidden;

char *b3items[B3FIXED+MAXHIDDEN+1];
Menu b3menu = { b3items };

int requirePosition = 0;

char *menu_items[] = MENU_ITEMS;
struct MenuItem **dynmenu_items = NULL;
int dynmenu_count = 0;

/* Window list menu (Button2 on root, like cwm windowmenu) */
#define MAXWINMENU 64
static char *winmenu_labels[MAXWINMENU + 1];
static Client *winmenu_clients[MAXWINMENU];
static int winmenu_count = 0;
static Menu winmenu = { winmenu_labels };

static void wrap_move(Client *c, ScreenInfo *s) { if(c) move(c, MENU_MOVE_BUTTON); }
static void wrap_reshape(Client *c, ScreenInfo *s) { if(c) reshape(c, MENU_RESIZE_BUTTON, sweep, NULL); }
static void wrap_hide(Client *c, ScreenInfo *s) { if(c) hide(c); }
static void wrap_delete(Client *c, ScreenInfo *s) { if(c) delete(c, 0); }
static void wrap_maximize(Client *c, ScreenInfo *s) { if(c) maximize(c, s); }
static void wrap_new(Client *c, ScreenInfo *s) { spawn_prompt(s); }
static void wrap_terminal(Client *c, ScreenInfo *s) { spawn_terminal(s); }
static void wrap_tile(Client *c, ScreenInfo *s) { if(s) tile_windows(s); }

static void wrap_move_selected(ScreenInfo *s) {
    Client *c = selectwin(0, 0, s);
    if(c) move(c, MENU_MOVE_BUTTON);
}

static void wrap_reshape_selected(ScreenInfo *s) {
    Client *c = selectwin(1, 0, s);
    if(c) reshape(c, MENU_RESIZE_BUTTON, sweep, NULL);
}

static void wrap_delete_selected(ScreenInfo *s) {
    int shift = 0;
    Client *c = selectwin(1, &shift, s);
    if(c) delete(c, shift);
}

static void wrap_hide_selected(ScreenInfo *s) {
    Client *c = selectwin(1, 0, s);
    if(c) hide(c);
}

static void wrap_maximize_selected(ScreenInfo *s) {
    Client *c = selectwin(1, 0, s);
    if(c) maximize(c, s);
}

static void wrap_tile_selected(ScreenInfo *s) {
    tile_windows(s);
}

static void spawn_common_with_cmd(ScreenInfo *s, char *cmd, int need_position);

void
maximize(Client *c, ScreenInfo *s)
{
	XSizeHints saved_hints;
	
	if(c == NULL || s == NULL)
		return;

	if(c->ismaximized) {
		c->ismaximized = 0;
		c->x = c->pre_x;
		c->y = c->pre_y;
		c->dx = c->pre_dx;
		c->dy = c->pre_dy;
		
		int screen_x = get_screen_x(s, c->x);
		int screen_y = get_screen_y(s, c->y);
		int tb = BORDER + INNER_BORDER;
		int title_offset = 0;
#if TITLEBARS
		title_offset = TITLEHEIGHT;
#endif
		
		XMoveResizeWindow(dpy, c->parent,
			screen_x - tb,
			screen_y - tb - title_offset,
			c->dx + 2*tb,
			c->dy + 2*tb + title_offset);
		
		XMoveResizeWindow(dpy, c->parent2,
			BORDER,
			BORDER + title_offset,
			c->dx + 2*INNER_BORDER,
			c->dy + 2*INNER_BORDER);
		
		XMoveResizeWindow(dpy, c->window, INNER_BORDER, INNER_BORDER, c->dx, c->dy);
		XSetWindowBorderWidth(dpy, c->parent, 0);
		XSetWindowBorderWidth(dpy, c->parent2, 0);
	}
	else {
		c->pre_x = c->x;
		c->pre_y = c->y;
		c->pre_dx = c->dx;
		c->pre_dy = c->dy;
		c->ismaximized = 1;
		
		saved_hints = c->size;
		c->size.flags &= ~(PMinSize | PMaxSize | PAspect);
		
		c->dx = s->width;
		c->dy = s->height;
		c->x = get_world_x(s, 0);
		c->y = get_world_y(s, 0);
		
		XMoveResizeWindow(dpy, c->parent, 0, 0, s->width, s->height);
		XMoveResizeWindow(dpy, c->parent2, 0, 0, s->width, s->height);
		XMoveResizeWindow(dpy, c->window, 0, 0, s->width, s->height);
		XSetWindowBorderWidth(dpy, c->parent, 0);
		XSetWindowBorderWidth(dpy, c->parent2, 0);
		XSetWindowBorderWidth(dpy, c->window, 0);
		XRaiseWindow(dpy, c->parent);
		
		c->size = saved_hints;
	}
	
	draw_border(c, c == current);
	sendconfig(c);
	active(c);
	XSync(dpy, False);
}

struct {
    char *name;
    void (*func)(Client*, ScreenInfo*);
    void (*selfunc)(ScreenInfo*);
} wmfuncs[] = {
    {"move", wrap_move, wrap_move_selected},
    {"resize", wrap_reshape, wrap_reshape_selected},
    {"maximize", wrap_maximize, wrap_maximize_selected},
    {"hide", wrap_hide, wrap_hide_selected},
    {"delete", wrap_delete, wrap_delete_selected},
    {"new", wrap_new, spawn_prompt},
    {"term", wrap_terminal, spawn_terminal},
    {"tile", wrap_tile, wrap_tile_selected},
    {NULL, NULL, NULL}
};

void
initdynmenu(void)
{
    int i, j;
    char *item, *colon, *label_copy;
    
    for(dynmenu_count = 0; menu_items[dynmenu_count] != NULL; dynmenu_count++)
        ;
    
    if(dynmenu_count == 0) {
        dynmenu_items = NULL;
        return;
    }
    
    dynmenu_items = malloc(dynmenu_count * sizeof(struct MenuItem *));
    if(dynmenu_items == NULL) {
        dynmenu_count = 0;
        return;
    }
    
    for(i = 0; i < dynmenu_count; i++) {
        dynmenu_items[i] = malloc(sizeof(struct MenuItem));
        if(dynmenu_items[i] == NULL) continue;
        
        item = menu_items[i];
        
        if(strcmp(item, "---") == 0 || strcmp(item, "|") == 0) {
            dynmenu_items[i]->type = MENU_SEPARATOR;
            dynmenu_items[i]->label = strdup("---");
            continue;
        }
        
        if(item[0] == '[' && item[strlen(item)-1] == ']') {
            dynmenu_items[i]->type = MENU_LABEL;
            label_copy = strdup(item + 1);
            label_copy[strlen(label_copy)-1] = '\0';
            dynmenu_items[i]->label = label_copy;
            continue;
        }
        
        if(item[0] == '@' && strlen(item) > 1) {
            dynmenu_items[i]->type = MENU_FUNC;
            char *funcname = item + 1;
            dynmenu_items[i]->label = strdup(funcname);
            
            for(j = 0; wmfuncs[j].name != NULL; j++) {
                if(strcmp(funcname, wmfuncs[j].name) == 0) {
                    dynmenu_items[i]->action.func = wmfuncs[j].func;
                    break;
                }
            }
            if(wmfuncs[j].name == NULL) {
                dynmenu_items[i]->type = MENU_SHELL;
                dynmenu_items[i]->action.cmd = strdup(funcname);
            }
            continue;
        }
        
        label_copy = strdup(item);
        colon = strchr(label_copy, ':');
        if(colon != NULL) {
            *colon = '\0';
            dynmenu_items[i]->type = MENU_SHELL;
            dynmenu_items[i]->label = strdup(label_copy);
            dynmenu_items[i]->action.cmd = strdup(colon + 1);
            free(label_copy);
        } else {
            dynmenu_items[i]->type = MENU_SHELL;
            dynmenu_items[i]->label = label_copy;
            dynmenu_items[i]->action.cmd = strdup(item);
        }
    }
}

void
build_dynmenu(void)
{
    static char *menu_display_items[MAXHIDDEN + 32];
    int i, j = 0;
    
    for(i = 0; i < dynmenu_count; i++)
        menu_display_items[j++] = dynmenu_items[i]->label;
    
    for(i = 0; i < numhidden; i++)
        menu_display_items[j++] = hiddenc[i]->label;
    
    menu_display_items[j] = NULL;
    b3menu.item = menu_display_items;
}

void
execmenuitem(int n, Client *c, ScreenInfo *s)
{
    if(n < 0 || n >= dynmenu_count + numhidden)
        return;
    
    if(n >= dynmenu_count) {
        unhide(n - dynmenu_count, 1);
        return;
    }
    
    struct MenuItem *item = dynmenu_items[n];
    
    switch(item->type) {
        case MENU_SHELL:
            spawn_common_with_cmd(s, item->action.cmd, 1);
            break;
            
        case MENU_FUNC:
            if(item->action.func != NULL) {
                if(c == NULL) {
                    /* Find selfunc and call it */
                    int i;
                    for(i = 0; wmfuncs[i].name != NULL; i++) {
                        if(wmfuncs[i].func == item->action.func) {
                            if(wmfuncs[i].selfunc)
                                wmfuncs[i].selfunc(s);
                            break;
                        }
                    }
                } else {
                    item->action.func(c, s);
                }
            }
            break;
            
        default:
            break;
    }
}

static void
spawn_common_with_cmd(ScreenInfo *s, char *cmd, int need_position)
{
    if(s == NULL)
        return;
    
    if(fork() == 0) {
        if(dpy)
            close(ConnectionNumber(dpy));
        if(s->display[0] != '\0')
            putenv(s->display);
        signal(SIGINT, SIG_DFL);
        signal(SIGTERM, SIG_DFL);
        signal(SIGHUP, SIG_DFL);
        setsid();
        if(cmd != NULL)
            execl(shell, shell, "-c", cmd, NULL);
        else
            execl(shell, shell, "-c", TERMINAL, NULL);
        perror("5element: exec failed");
        exit(1);
    }
}

static void
build_winmenu(ScreenInfo *s)
{
	Client *c;
	int n = 0;

	for(c = clients; c && n < MAXWINMENU; c = c->next) {
		if(c->screen != s)
			continue;
		if(!normal(c) && !hidden(c))
			continue;
		if(c->parent == c->screen->root)
			continue;
		winmenu_clients[n] = c;
		winmenu_labels[n] = c->label ? c->label : "???";
		n++;
	}
	winmenu_labels[n] = NULL;
	winmenu_count = n;
}

void
button(XButtonEvent *e)
{
	Client *c;
	ScreenInfo *s;
	Window dw;
	int tb = BORDER + INNER_BORDER;

	curtime = e->time;
	s = getscreen(e->root);
	if(s == 0)
		return;

	/* Handle panning start/stop */
	if(e->button == PAN_BUTTON) {
	    if(e->type == ButtonPress) {
#if PAN_MOD_ENABLED
	        if((e->state & PAN_MOD) == PAN_MOD)
#endif
	        {
	            panning = 1;
	            pan_start_x = e->x_root;
	            pan_start_y = e->y_root;
	            pan_start_scroll_x = s->scroll_x;
	            pan_start_scroll_y = s->scroll_y;
		    XDefineCursor(dpy, s->root, s->pan);
	            XAllowEvents(dpy, AsyncPointer, e->time);
	            return;
	        }
	} else if(e->type == ButtonRelease && panning) {
	        panning = 0;
	        XDefineCursor(dpy, s->root, s->arrow);
	        XAllowEvents(dpy, AsyncPointer, e->time);
	        return;
	}
}

	if(panning) {
		XAllowEvents(dpy, AsyncPointer, e->time);
		return;
	}

	if(e->type == ButtonRelease)
		return;

	/* Button2 on root: window list menu (like cwm windowmenu) */
	if(e->button == WINMENU_BUTTON && (e->window == s->root || getclient(e->window, 0) == NULL)) {
		Client *cc;
		cc = getclient(e->window, 0);
		if(cc == NULL) {
			build_winmenu(s);
			if(winmenu_count == 0)
				return;
			if(current && current->screen == s)
				cmapnofocus(s);
			int n = menuhit(e, &winmenu);
			if(n >= 0 && n < winmenu_count) {
				Client *target = winmenu_clients[n];
				if(hidden(target))
					unhidec(target, 1);
				else {
					XMapRaised(dpy, target->parent);
					top(target);
					active(target);
					center_camera_on_window(target);
				}
			}
			if(current && current->screen == s)
				cmapfocus(current);
			return;
		}
	}

	c = getclient(e->window, 0);
	
#if TITLEBARS
	if(c && e->window == c->parent) {
		if(intitle(c, e->x, e->y)) {
#if CLOSEBUTTON
			if(inclosebutton(c, e->x, e->y)) {
				delete(c, 0);
				return;
			}
#endif
			if(e->button == TITLE_MOVE) {
				move(c, TITLE_MOVE);
				return;
			}
		}
	}
#endif
	
	if(c) {
		if(e->x < tb || e->x > c->dx + tb || e->y < tb || e->y > c->dy + tb) {
			if((e->state & PAN_MOD) == 0) {
				switch (e->button) {
				case BORDER_RESIZE_BUTTON:
				case BORDER_PULL_BUTTON:
					reshape(c, e->button, pull, e);
					return;
				case BORDER_MOVE_BUTTON:
					move(c, BORDER_MOVE_BUTTON);
					return;
				default:
					return;
				}
			}
		}
		e->x += c->x - tb;
		e->y += c->y - tb;
	} else if(e->window != e->root) {
		XTranslateCoordinates(dpy, e->window, s->root, e->x, e->y,
		                    &e->x, &e->y, &dw);
	}
	
	if (e->button == SPAWN_ACTIVATE_BUTTON || e->button == MAIN_MENU_BUTTON) {
		if(c) {
			XMapRaised(dpy, c->parent);
			top(c);
			active(c);
			XAllowEvents(dpy, ReplayPointer, curtime);
		} else {
			if(current && current->screen == s)
				cmapnofocus(s);
			
			build_dynmenu();
			int n = menuhit(e, &b3menu);
			
			if(n != -1)
				execmenuitem(n, c, s);
			
			if(current && current->screen == s)
				cmapfocus(current);
		}
		return;
	}
}

void
spawn_prompt(ScreenInfo *s)
{
    char cmd[512];
    snprintf(cmd, sizeof(cmd), LAUNCHER);
    spawn_common_with_cmd(s, cmd, 1);
}

void
spawn_terminal(ScreenInfo *s)
{
    spawn_common_with_cmd(s, NULL, 1);
}

void
reshape(Client *c, int but, int (*fn)(Client*, int, XButtonEvent*), XButtonEvent *e)
{
	extern int panning;
	
	if(panning)
		return;
	
	int odx, ody;

	if(c == 0) return;
	odx = c->dx;
	ody = c->dy;
	if(fn(c, but, e) == 0) return;
	active(c);
	top(c);
	XRaiseWindow(dpy, c->parent);
	
#if TITLEBARS
	int title_offset = TITLEHEIGHT;
#else
	int title_offset = 0;
#endif
	
	int screen_x = get_screen_x(c->screen, c->x);
	int screen_y = get_screen_y(c->screen, c->y);
	
	XMoveResizeWindow(dpy, c->parent, 
	                screen_x - BORDER, 
	                screen_y - BORDER - title_offset,
	                c->dx + 2*BORDER + 2*INNER_BORDER, 
	                c->dy + 2*BORDER + 2*INNER_BORDER + title_offset);
	XMoveResizeWindow(dpy, c->parent2, 
	                BORDER, 
	                BORDER + title_offset,
	                c->dx + 2*INNER_BORDER, 
	                c->dy + 2*INNER_BORDER);
	
	draw_border(c, 1);
	
	if(c->dx == odx && c->dy == ody)
		sendconfig(c);
	else
		XMoveResizeWindow(dpy, c->window, INNER_BORDER, INNER_BORDER, c->dx, c->dy);
}

void
move(Client *c, int but)
{
	extern int panning;
	
	if(panning)
		return;
	
#if TITLEBARS
	int title_offset = TITLEHEIGHT;
#else
	int title_offset = 0;
#endif
	
	if(c == 0) return;
	if(drag(c, but) == 0) return;
	active(c);
	top(c);
	XRaiseWindow(dpy, c->parent);
	
	int screen_x = get_screen_x(c->screen, c->x);
	int screen_y = get_screen_y(c->screen, c->y);
	
	XMoveWindow(dpy, c->parent, 
	           screen_x - BORDER, 
	           screen_y - BORDER - title_offset);
	
	draw_border(c, 1);
	sendconfig(c);
}

void
delete(Client *c, int shift)
{
	if(c == 0) return;
	if((c->proto & Pdelete) && !shift)
		sendcmessage(c->window, wm_protocols, wm_delete, 0, 0);
	else
		XKillClient(dpy, c->window);
}

void
hide(Client *c)
{
	if(c == 0 || numhidden == MAXHIDDEN) return;
	if(hidden(c)) {
		fprintf(stderr, "5element: already hidden: %s\n", c->label);
		return;
	}
	XUnmapWindow(dpy, c->parent);
	XUnmapWindow(dpy, c->window);
	setstate(c, IconicState);
	if(c == current) nofocus();
	
	hiddenc[numhidden] = c;
	b3items[B3FIXED+numhidden] = c->label;
	numhidden++;
	b3items[B3FIXED+numhidden] = 0;
}

void
unhide(int n, int map)
{
	Client *c;
	int i;
#if TITLEBARS
	int title_offset = TITLEHEIGHT;
#else
	int title_offset = 0;
#endif

	if(n >= numhidden) {
		fprintf(stderr, "5element: unhide: n %d numhidden %d\n", n, numhidden);
		return;
	}
	c = hiddenc[n];
	if(!hidden(c)) {
		fprintf(stderr, "5element: unhide: not hidden: %s(0x%x)\n", c->label, (int)c->window);
		return;
	}

	if(map) {
		if(!sweep(c, SPAWN_ACTIVATE_BUTTON, 0))
			return;
		
		int screen_x = get_screen_x(c->screen, c->x);
		int screen_y = get_screen_y(c->screen, c->y);
		
		XMoveResizeWindow(dpy, c->parent, 
		                 screen_x - BORDER, 
		                 screen_y - BORDER - title_offset,
		                 c->dx + 2*BORDER + 2*INNER_BORDER, 
		                 c->dy + 2*BORDER + 2*INNER_BORDER + title_offset);
		XMoveResizeWindow(dpy, c->parent2, 
		                 BORDER, 
		                 BORDER + title_offset,
		                 c->dx + 2*INNER_BORDER, 
		                 c->dy + 2*INNER_BORDER);
		XMoveResizeWindow(dpy, c->window, INNER_BORDER, INNER_BORDER, c->dx, c->dy);
		
		XMapWindow(dpy, c->window);
		XMapWindow(dpy, c->parent2);
		XMapRaised(dpy, c->parent);
		setstate(c, NormalState);
		active(c);
		top(c);
		draw_border(c, 1);
	}

	numhidden--;
	for(i = n; i < numhidden; i++) {
		hiddenc[i] = hiddenc[i+1];
		b3items[B3FIXED+i] = b3items[B3FIXED+i+1];
	}
	b3items[B3FIXED+numhidden] = 0;
}

void
unhidec(Client *c, int map)
{
	int i;
	for(i = 0; i < numhidden; i++)
		if(c == hiddenc[i]) {
			unhide(i, map);
			return;
		}
	fprintf(stderr, "5element: unhidec: not hidden: %s(0x%x)\n", c->label, (int)c->window);
}

void
renamec(Client *c, char *name)
{
	int i;
	if(name == 0) name = "???";
	c->label = name;
	if(!hidden(c)) return;
	for(i = 0; i < numhidden; i++)
		if(c == hiddenc[i]) {
			b3items[B3FIXED+i] = name;
			return;
		}
}
