#!/bin/bash
path=/usr/local/bin/

mk clean && NPROC=$(nproc) mk

if [ -f "o.5element" ]; then
    doas rm -f "$path/5element"
    doas cp o.5element "$path/5element"
    echo "ok"
	mk clean
else
    echo "error: no file"
    exit 1
fi
