#ifndef CONFIG_H
#define CONFIG_H

/* ==================== GENERAL SETTINGS ==================== */

/* Refreshrate */
#define REFRESHRATE   144

/* Title bars */
#define TITLEBARS 0        /* 0 = no title bars, 1 = show title bars */
#define TITLEHEIGHT 20     /* Height of title bar in pixels */
#define CLOSEBUTTON 0      /* Enable close button(on titlebars) */
#define TITLE_TEXT 0       /* window name on titlebar */
#define CLOSE_BUTTON_SIZE 9 /* close button size */

/* Border settings */
#define BORDER          5      /* Outer border thickness */
#define INNER_BORDER    3     /* Inner border thickness */

/* Cursor style: 0 = classic rio, 1 = blit */
/* NOTE: CURSOR only affects which bitmap set is the default when   */
/* CURSOR_DEF() is used below. Each slot can be overridden freely.  */
#define CURSOR 0

/* ==================== CURSOR CONFIGURATION ==================== */
/*
 * For each cursor slot, choose ONE of:
 *
 *   CURSOR_DEF(name)   -- use a built-in bitmap cursor.
 *                         Available names:
 *                           bigarrow    (classic rio arrow)
 *                           arrowdata   (smaller classic arrow)
 *                           whitearrow  (white variant)
 *                           sightdata   (crosshair/target)
 *                           sweep0data  (cross, for resize start)
 *                           boxcursdata (box, for drag/resize)
 *                           blitarrow   (blit-style arrow)
 *                           blittarget  (blit-style target)
 *                           blitsweep   (blit-style sweep)
 *
 *   CURSOR_XC(xc)      -- use an X11 font cursor.
 *                         Pass the XC_* constant, e.g. CURSOR_XC(XC_fleur)
 *                         Full list in <X11/cursorfont.h>
 */

/* Normal pointer (root + inactive windows) */
#define CURSOR_ARROW      CURSOR_DEF(bigarrow)

/* Window select (pick window from menu) */
#define CURSOR_TARGET     CURSOR_DEF(sightdata)

/* Resize start (before button is pressed) */
#define CURSOR_SWEEP0     CURSOR_DEF(sweep0data)

/* Drag / resize in progress */
#define CURSOR_BOX        CURSOR_DEF(boxcursdata)

/* Move window */
#define CURSOR_MOVE       CURSOR_XC(XC_fleur)

/* Pan / scroll viewport */
#define CURSOR_PAN        CURSOR_XC(XC_bottom_side)

/* Focus behavior: 0 = click-to-focus, 1 = focus follows mouse */
#define FFM 1

/* Put window on top when focused */
#define UP_ON_FOCUS 0

/* ==================== FONT SETTINGS ==================== */

#define TITLE_FONT "9x15bold"
#define MENU_FONT  "9x15bold"

/* ==================== COLORS ==================== */

/* Main border colors (outer border) */
#define ACTIVE_BORDER_COLOR          0x2d353b
#define INACTIVE_BORDER_COLOR        0x2d353b

/* Secondary border colors (inner border) */
#define ACTIVE_INNER_BORDER_COLOR         0xD9D5B9
#define INACTIVE_INNER_BORDER_COLOR       0x909090

/* Title bar colors */
#define TITLE_ACTIVE_COLOR           0xa18faf
#define TITLE_INACTIVE_COLOR         0xc19fbf
#define TITLE_TEXT_ACTIVE_COLOR      0x000000
#define TITLE_TEXT_INACTIVE_COLOR    0x666666

/* Close button (X) colors */
#define TITLE_CLOSE_ACTIVE_COLOR     0x000000
#define TITLE_CLOSE_INACTIVE_COLOR   0x666666

/* Menu colors */
#define MENU_BACKGROUND_COLOR        0x2D353B
#define MENU_TEXT_COLOR              0xD3C6AA
#define MENU_ACTIVE_BACKGROUND_COLOR 0xD3C6AA
#define MENU_BORDER_COLOR            0xD3C6AA

/* ==================== TILING SETTINGS ==================== */

/* Gaps between tiled windows */
#define GAPS 60

/* Tiling layouts */
#define GRID   0
#define MASTER 1
#define ROWS   2
#define COLS   3

/* Default tiling layout */
#define DEFAULT_TILE_LAYOUT MASTER

/* Master width ratio (0-100) for MASTER layout */
#define MASTER_WIDTH_RATIO 50

/* ==================== KEY BINDINGS ==================== */

/* Main modifier key for WM actions */
#define WM_MOD Mod4Mask

/* Fullscreen toggle */
#define FULLSCREEN_KEY XK_f
#define FULLSCREEN_MOD WM_MOD

/* Window switching */
#define ALT_TAB_KEY XK_Tab
#define ALT_TAB_MOD WM_MOD

/* === CAMERA/VIEWPORT CONTROL === */

#define CENTER_ON_HOME_KEY XK_v
#define CENTER_ON_HOME_MOD WM_MOD

#define CENTER_ON_WIN_KEY XK_c
#define CENTER_ON_WIN_MOD WM_MOD

/* ==================== SCROLLABLE VIEWPORT SETTINGS ==================== */

/* Use mod or only mouse button */
#define PAN_MOD_ENABLED 0

#define PAN_BUTTON   Button2
#define PAN_MOD      WM_MOD

/* ==================== MOUSE BINDINGS ==================== */

/* Move windows with titlebars */
#define TITLE_MOVE Button1

/* Applications menu */
#define WINMENU_BUTTON          Button1

/* Spawn and activate windows */
#define SPAWN_ACTIVATE_BUTTON   Button3

/* Main menu */
#define MAIN_MENU_BUTTON        Button3

/* Move window */
#define BORDER_MOVE_BUTTON      Button3

/* Resize window */
#define BORDER_RESIZE_BUTTON    Button1

/* Pull resize */
#define BORDER_PULL_BUTTON      Button2

/* Select window from menu */
#define MENU_SELECT_BUTTON      Button3

/* Move window from menu */
#define MENU_MOVE_BUTTON        Button3

/* Resize window from menu */
#define MENU_RESIZE_BUTTON      Button3

/* ==================== CUSTOM KEY BINDINGS ==================== */

#define CUSTOM_KEYS \
    { WM_MOD,             XK_r,      "5element restart" },      \
    { WM_MOD,             XK_F12,    "powermenu" },             \
    { WM_MOD,             XK_q,      "xdotool getwindowfocus windowclose" }, \
    { WM_MOD,             XK_x,      "/home/kuromi/.bin/toggle_bar" }, \
    { WM_MOD|ShiftMask,   XK_q,      "5element exit" },               \

/* ==================== MENU CONFIGURATION ==================== */

#define MENU_ITEMS { \
    "@new",      \
    "@term",     \
    "firefox",   \
    "nekoray:pkill nekobox; nekoray",   \
    "acme",      \
    "shot",	 \
    "@hide",     \
    "@move",     \
    "@resize",   \
    "@delete",   \
    "@tile",     \
    NULL \
}

/* ==================== EXTERNAL COMMANDS ==================== */

#define LAUNCHER "cmenu-run"
#define TERMINAL "st"

/* ==================== AUTOSTART ==================== */
#define AUTOSTART_PROGRAMS \
	"xrdb -merge /home/kuromi/.Xresources", \
    "hsetroot -cover ~/.flow.png", \
    /* Add your programs here */

/* ==================== XOR COLOR SETTINGS ==================== */

#define XOR_FOREGROUND_COLOR (BlackPixel(dpy, i) ^ WhitePixel(dpy, i))
#define XOR_BACKGROUND_COLOR WhitePixel(dpy, i)

#endif /* CONFIG_H */
