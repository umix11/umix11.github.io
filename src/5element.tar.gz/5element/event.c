/* Copyright (c) 1994-1996 David Hogan, see README for licence details */
#include <stdio.h>
#include <stdlib.h>
#include <X11/X.h>
#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/extensions/shape.h>
#include "dat.h"
#include "fns.h"
#include "patchlevel.h"
#include "config.h"

void
mainloop(int shape_event)
{
	XEvent ev;
	for(;;){
		getevent(&ev);

#ifdef	DEBUG_EV
		if(debug){
			ShowEvent(&ev);
			printf("\n");
		}
#endif
		switch (ev.type){
		case MotionNotify:
			motionnotify(&ev.xmotion);
			break;
		case KeyPress:
			keypress(&ev.xkey);
			break;
		case KeyRelease:
			keyrelease(&ev.xkey);
			break;
		case ButtonPress:
		case ButtonRelease:
			button(&ev.xbutton);
			break;
		case MapRequest:
			mapreq(&ev.xmaprequest);
			break;
		case ConfigureRequest:
			configurereq(&ev.xconfigurerequest);
			break;
		case CirculateRequest:
			circulatereq(&ev.xcirculaterequest);
			break;
		case UnmapNotify:
			unmap(&ev.xunmap);
			break;
		case CreateNotify:
			newwindow(&ev.xcreatewindow);
			break;
		case DestroyNotify:
			destroy(ev.xdestroywindow.window);
			break;
		case ClientMessage:
			clientmesg(&ev.xclient);
			break;
		case ColormapNotify:
			cmap(&ev.xcolormap);
			break;
		case PropertyNotify:
			property(&ev.xproperty);
			break;
		case SelectionClear:
			fprintf(stderr, "5element: SelectionClear (this should not happen)\n");
			break;
		case SelectionNotify:
			fprintf(stderr, "5element: SelectionNotify (this should not happen)\n");
			break;
		case SelectionRequest:
			fprintf(stderr, "5element: SelectionRequest (this should not happen)\n");
			break;
		case EnterNotify:
			enter(&ev.xcrossing);
			break;
		case LeaveNotify:
			leave(&ev.xcrossing);
			break;
		case ReparentNotify:
			reparent(&ev.xreparent);
			break;
		case FocusIn:
			focusin(&ev.xfocus);
			break;
            default:
#ifdef SHAPE
                if(shape && ev.type == shape_event)
                    shapenotify((XShapeEvent *)&ev);
#endif
                break;

case Expose:
{
    Client *c;

    c = getclient(ev.xexpose.window, 0);
    if(c && ev.xexpose.window == c->parent) {
#if TITLEBARS
        draw_title(c, (c == current));
#endif
    }
    break;
}

		case NoExpose:
		case FocusOut:
		case ConfigureNotify:
		case MapNotify:
		case MappingNotify:
		case GraphicsExpose:
			trace("ignore", 0, &ev);
			break;
		}
	}
}


void
configurereq(XConfigureRequestEvent *e)
{
	XWindowChanges wc;
	Client *c;

	c = getclient(e->window, 0);
  if(c){
		sendconfig(c); 
		return;
	}
	trace("configurereq", c, e);

	e->value_mask &= ~CWSibling;

	if(c){
		if(e->value_mask & CWX)
			c->x = e->x;
		if(e->value_mask & CWY)
			c->y = e->y;
		if(e->value_mask & CWWidth)
			c->dx = e->width;
		if(e->value_mask & CWHeight)
			c->dy = e->height;
		if(e->value_mask & CWBorderWidth)
			c->border = e->border_width;

		if(c->dx >= c->screen->width && c->dy >= c->screen->height)
			c->border = 0;
		else
			c->border = BORDER;

		if(e->value_mask & CWStackMode){
			if(e->detail == Above)
				top(c);
			else
				e->value_mask &= ~CWStackMode;
		}
		e->value_mask |= CWX|CWY|CWHeight|CWWidth;

		if(c->parent != c->screen->root && c->window == e->window){
			int tb = BORDER + INNER_BORDER;
			int screen_x = get_screen_x(c->screen, c->x);
			int screen_y = get_screen_y(c->screen, c->y);

			wc.x = screen_x - tb;
			wc.y = screen_y - tb;
			wc.width = c->dx + 2*tb;
			wc.height = c->dy + 2*tb;
			wc.border_width = 1;
			wc.sibling = None;
			wc.stack_mode = e->detail;
			XConfigureWindow(dpy, c->parent, e->value_mask, &wc);

			wc.x = BORDER;
			wc.y = BORDER;
			wc.width = c->dx+2*INNER_BORDER;
			wc.height = c->dy+2*INNER_BORDER;
			XConfigureWindow(dpy, c->parent2, e->value_mask, &wc);

			if(e->value_mask & CWStackMode){
				top(c);
				active(c);
			}
		}
	}

	if(c && c->parent != c->screen->root){
		wc.x = INNER_BORDER;
		wc.y = INNER_BORDER;
	}else {
		wc.x = c->x;
		wc.y = c->y;
	}
	wc.width = c->dx;
	wc.height = c->dy;
	wc.border_width = 0;
	wc.sibling = None;
	wc.stack_mode = Above;
	e->value_mask &= ~CWStackMode;
	e->value_mask |= CWBorderWidth;
	XConfigureWindow(dpy, c->window, e->value_mask, &wc);
  sendconfig(c);
}

void
mapreq(XMapRequestEvent *e)
{
	Client *c;
	int i;

	curtime = CurrentTime;
	c = getclient(e->window, 0);
	trace("mapreq", c, e);

	if(c == 0 || c->window != e->window){
		fprintf(stderr, "5element: bad mapreq c %p w %x, rescanning\n",
			(void*)c, (int)e->window);
		for(i = 0; i < num_screens; i++)
			scanwins(&screens[i]);
		c = getclient(e->window, 0);
		if(c == 0 || c->window != e->window){
			fprintf(stderr, "5element: window not found after rescan\n");
			return;
		}
	}

	switch (c->state){
	case WithdrawnState:
		if(c->parent == c->screen->root){
			if(!manage(c, 0))
				return;
			break;
		}
		XReparentWindow(dpy, c->window, c->parent2, INNER_BORDER, INNER_BORDER);
		XAddToSaveSet(dpy, c->window);
	case NormalState:
		XMapWindow(dpy, c->window);
		XMapWindow(dpy, c->parent2);
		XMapRaised(dpy, c->parent);
		top(c);
		setstate(c, NormalState);
		if(c->trans != None && current && c->trans == current->window)
				active(c);
		break;
	case IconicState:
		unhidec(c, 1);
		break;
	}
}

void
unmap(XUnmapEvent *e)
{
	Client *c;

	curtime = CurrentTime;
	c = getclient(e->window, 0);
	if(c){
		switch (c->state){
		case IconicState:
			if(e->send_event){
				unhidec(c, 0);
				withdraw(c);
			}
			break;
		case NormalState:
			if(c == current)
				nofocus();
			if(!c->reparenting)
				withdraw(c);
			break;
		}
		c->reparenting = 0;
	}
}

void
circulatereq(XCirculateRequestEvent *e)
{
	fprintf(stderr, "It must be the warlock Krill!\n");
}

void
newwindow(XCreateWindowEvent *e)
{
	Client *c;
	ScreenInfo *s;

	if(e->override_redirect)
		return;
	c = getclient(e->window, 1);
	if(c && c->window == e->window && (s = getscreen(e->parent))){
		c->x = get_world_x(s, e->x);  /* Convert screen X to world X */
		c->y = get_world_y(s, e->y);  /* Convert screen Y to world Y */
		c->dx = e->width;
		c->dy = e->height;
		c->border = e->border_width;
		c->screen = s;
		if(c->parent == None)
			c->parent = c->screen->root;
	}
}

void
destroy(Window w)
{
	Client *c;

	curtime = CurrentTime;
	c = getclient(w, 0);
	if(c == 0)
		return;

	rmclient(c);

	ignore_badwindow = 1;
	XSync(dpy, False);
	ignore_badwindow = 0;
}

void
clientmesg(XClientMessageEvent *e)
{
	Client *c;

	curtime = CurrentTime;
	if(e->message_type == exit_5element){
		cleanup();
		exit(0);
	}
	if(e->message_type == restart_5element){
		fprintf(stderr, "*** 5element restarting ***\n");
		cleanup();
		execvp(myargv[0], myargv);
		perror("5element: exec failed");
		exit(1);
	}
	if(e->message_type == wm_protocols)
		return;
	if(e->message_type == wm_change_state){
		c = getclient(e->window, 0);
		if(e->format == 32 && e->data.l[0] == IconicState && c != 0){
			if(normal(c))
				hide(c);
		}
		else
			fprintf(stderr, "5element: WM_CHANGE_STATE: format %d data %d w 0x%x\n",
				(int)e->format, (int)e->data.l[0], (int)e->window);
		return;
	}
	if(e->message_type == wm_state){
		c = getclient(e->window, 0);
		if (!c) return;
		
		Atom fullscreen = XInternAtom(dpy, "_NET_WM_STATE_FULLSCREEN", False);
		long action = e->data.l[0];  /* 0=remove, 1=add, 2=toggle */
		long data1 = e->data.l[1];
		long data2 = e->data.l[2];
		ScreenInfo *s = c->screen;
		
		if(debug) {
			fprintf(stderr, "5element: WM_STATE: action=%ld data1=%ld data2=%ld w=0x%x\n",
				action, data1, data2, (int)e->window);
		}
		
		/* Проверяем, относится ли сообщение к fullscreen */
		if (data1 == fullscreen || data2 == fullscreen) {
			/* maximize уже работает как toggle, просто вызываем её */
			maximize(c, s);
		}
		return;
	}
	fprintf(stderr, "5element: strange ClientMessage, type 0x%x window 0x%x\n",
		(int)e->message_type, (int)e->window);
}

void
cmap(XColormapEvent *e)
{
	Client *c;
	int i;

	if(e->new){
		c = getclient(e->window, 0);
		if(c){
			c->cmap = e->colormap;
			if(c == current)
				cmapfocus(c);
		}
		else
			for(c = clients; c; c = c->next){
				for(i = 0; i < c->ncmapwins; i++)
					if(c->cmapwins[i] == e->window){
						c->wmcmaps[i] = e->colormap;
						if(c == current)
							cmapfocus(c);
						return;
					}
			}
	}
}

void
property(XPropertyEvent *e)
{
    Atom a;
    int delete;
    Client *c;
    long msize;

    a = e->atom;
    delete = (e->state == PropertyDelete);
    c = getclient(e->window, 0);
    if(c == 0)
        return;

    switch (a){
    case XA_WM_ICON_NAME:
        if(c->iconname != 0)
            XFree((char*) c->iconname);
        c->iconname = delete ? 0 : getprop(c->window, a);
        setlabel(c);
        renamec(c, c->label);
        return;
    case XA_WM_NAME:
        if(c->name != 0)
            XFree((char*) c->name);
        c->name = delete ? 0 : getprop(c->window, a);
        setlabel(c);
        renamec(c, c->label);

#if TITLEBARS
        draw_title(c, (c == current));
#endif
        return;
    case XA_WM_TRANSIENT_FOR:
        gettrans(c);
        return;
    case XA_WM_HINTS:
    case XA_WM_SIZE_HINTS:
    case XA_WM_ZOOM_HINTS:
        return;
    case XA_WM_NORMAL_HINTS:
        if(XGetWMNormalHints(dpy, c->window, &c->size, &msize) == 0 || c->size.flags == 0)
            c->size.flags = PSize;
        return;
    }
    if(a == wm_colormaps){
        getcmaps(c);
        if(c == current)
            cmapfocus(c);
    }
}



void
reparent(XReparentEvent *e)
{
	Client *c;
	XWindowAttributes attr;
	ScreenInfo *s;

	if(!getscreen(e->event) || e->override_redirect)
		return;
	if((s = getscreen(e->parent)) != 0){
		c = getclient(e->window, 1);
		if(c != 0 && (c->dx == 0 || c->dy == 0)){
			ignore_badwindow = 1;
			XGetWindowAttributes(dpy, c->window, &attr);
			XSync(dpy, False);
			ignore_badwindow = 0;

			c->x = get_world_x(s, attr.x);  /* Convert screen to world coords */
			c->y = get_world_y(s, attr.y);  /* Convert screen to world coords */
			c->dx = attr.width;
			c->dy = attr.height;
			c->border = attr.border_width;
			c->screen = s;
			if(c->parent == None)
				c->parent = c->screen->root;
		}
	}
	else {
		c = getclient(e->window, 0);
		if(c != 0 && (c->parent == c->screen->root || withdrawn(c)))
			rmclient(c);
	}
}

#ifdef	SHAPE
void
shapenotify(XShapeEvent *e)
{
	Client *c;

	c = getclient(e->window, 0);
	if(c == 0)
		return;

	setshape(c);
}
#endif

void
enter(XCrossingEvent *e)
{
	Client *c;

	curtime = e->time;
	if(!ffm)
	if(e->mode != NotifyGrab || e->detail != NotifyNonlinearVirtual)
		return;
	c = getclient(e->window, 0);
	if(c != 0 && c != current){
		if (UP_ON_FOCUS) {
			XRaiseWindow(dpy, c->parent);
			XRaiseWindow(dpy, c->window);
		}
		top(c);
		active(c);
	}
}

void
leave(XCrossingEvent *e)
{
	Client *c;

	c = getclient(e->window, 0);
	if(c)
		XUndefineCursor(dpy, c->parent2);
}

void
focusin(XFocusChangeEvent *e)
{
	Client *c;

	curtime = CurrentTime;
	if(e->detail != NotifyNonlinearVirtual)
		return;
	c = getclient(e->window, 0);
	if(c != 0 && c->window == e->window && c != current){
		XMapRaised(dpy, c->parent);
		top(c);
		active(c);
	}
}

BorderOrient
borderorient(Client *c, int x, int y)
{
	int tb = BORDER + INNER_BORDER;
	
	if(x <= tb){
		if(y <= CORNER){
			if(debug) fprintf(stderr, "topleft\n");
			return BorderWNW;
		}
		if(y >= (c->dy + 2*tb) - CORNER){
			if(debug) fprintf(stderr, "botleft\n");
			return BorderWSW;
		}
		if(y > CORNER &&
			y < (c->dy + 2*tb) - CORNER){
			if(debug) fprintf(stderr, "left\n");
			return BorderW;
		}
	} else if(x <= CORNER){
		if(y <= tb){
			if(debug) fprintf(stderr, "topleft\n");
			return BorderNNW;
		}
		if  (y >= (c->dy + tb)){
			if(debug) fprintf(stderr, "botleft\n");
			return BorderSSW;
		}
	} else if(x >= (c->dx + tb)){
		if(y <= CORNER){
			if(debug) fprintf(stderr, "topright\n");
			return BorderENE;
		}
		if(y >= (c->dy + 2*tb) - CORNER){
			if(debug) fprintf(stderr, "botright\n");
			return BorderESE;
		}
		if(y > CORNER &&
			y < (c->dy + 2*tb) - CORNER){
			if(debug) fprintf(stderr, "right\n");
			return BorderE;
		}
	} else if(x >= (c->dx + 2*tb) - CORNER){
		if(y <= tb){
			if(debug) fprintf(stderr, "topright\n");
			return BorderNNE;
		}
		if  (y >= (c->dy + tb)){
			if(debug) fprintf(stderr, "botright\n");
			return BorderSSE;
		}
	} else if(x > CORNER &&
			x < (c->dx + 2*tb) - CORNER){
		if(y <= tb){
			if(debug) fprintf(stderr, "top\n");
			return BorderN;
		}
		if(y >= (c->dy + tb)){
			if(debug) fprintf(stderr, "bot\n");
			return BorderS;
		}
	}
	return BorderUnknown;
}

void
motionnotify(XMotionEvent *e)
{
	Client *c;
	BorderOrient bl;
	ScreenInfo *s;
	extern int panning;
	extern int pan_start_x, pan_start_y;
	extern int pan_start_scroll_x, pan_start_scroll_y;
	static Time last_motion_time = 0;
	Time motion_interval = 1000 / REFRESHRATE;  /* Milliseconds between updates */
	
	s = getscreen(e->root);
	
	/* Handle panning if active */
	if(panning && s) {
		/* Throttle motion events based on REFRESHRATE */
		if(last_motion_time != 0) {
			Time elapsed = e->time - last_motion_time;
			if(elapsed < motion_interval) {
				/* Skip this motion event - too soon */
				if(debug > 1)
					fprintf(stderr, "Motion throttled: elapsed=%ld ms, required=%ld ms\n",
					        (long)elapsed, (long)motion_interval);
				return;
			}
		}
		
		last_motion_time = e->time;
		
		int delta_x = pan_start_x - e->x_root;
		int delta_y = pan_start_y - e->y_root;
		
		s->scroll_x = pan_start_scroll_x + delta_x;
		s->scroll_y = pan_start_scroll_y + delta_y;
		
		apply_scroll_to_windows(s);
		
		if(debug)
			fprintf(stderr, "Panning: delta=(%d,%d) scroll=(%d,%d)\n",
			        delta_x, delta_y, s->scroll_x, s->scroll_y);
		return;
	}

	c = getclient(e->window, 0);
	if(c){
		bl = borderorient(c, e->x, e->y);
		if(bl == BorderUnknown)
			XUndefineCursor(dpy, c->parent2);
		else
			XDefineCursor(dpy, c->parent2, c->screen->bordcurs[bl]);
	}
}
