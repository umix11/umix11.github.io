/* tile.c - Window tiling functions */
#include <stdio.h>
#include <stdlib.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include "dat.h"
#include "fns.h"
#include "config.h"

static int count_visible_windows(ScreenInfo *s)
{
    Client *c;
    int count = 0;
    
    for (c = clients; c; c = c->next) {
        if (c->screen == s && !hidden(c) && !withdrawn(c)) {
            count++;
        }
    }
    return count;
}

static Client** get_visible_windows(ScreenInfo *s, int count)
{
    Client *c;
    Client **list;
    int i = 0;
    
    list = malloc(count * sizeof(Client*));
    if (!list) return NULL;
    
    for (c = clients; c; c = c->next) {
        if (c->screen == s && !hidden(c) && !withdrawn(c)) {
            list[i++] = c;
        }
    }
    return list;
}

static void apply_window_position(Client *c, int x, int y, int width, int height)
{
    int tb = BORDER + INNER_BORDER;
    
    c->x = x;
    c->y = y;
    c->dx = width;
    c->dy = height;
    
    XMoveResizeWindow(dpy, c->parent, c->x - tb, c->y - tb,
                      c->dx + 2*tb, c->dy + 2*tb);
    XMoveResizeWindow(dpy, c->parent2, BORDER, BORDER,
                      c->dx + 2*INNER_BORDER, c->dy + 2*INNER_BORDER);
    XClearWindow(dpy, c->parent);
    XClearWindow(dpy, c->parent2);
    XMoveResizeWindow(dpy, c->window, INNER_BORDER, INNER_BORDER, c->dx, c->dy);
    sendconfig(c);
}

void tile_windows_layout(ScreenInfo *s, int layout)
{
    int count, i;
    Client **windows;
    int screen_width, screen_height;
    int usable_width, usable_height;
    int start_x, start_y;
    
    if (!s) return;
    
    count = count_visible_windows(s);
    if (count == 0) return;
    
    windows = get_visible_windows(s, count);
    if (!windows) return;
    
    screen_width = s->width;
    screen_height = s->height;
    
    usable_width = screen_width - (GAPS * 2);
    usable_height = screen_height - (GAPS * 2);
    start_x = GAPS;
    start_y = GAPS;
    
    switch (layout) {
        case GRID: {
            int cols = (count <= 4) ? (count + 1) / 2 : 3;
            int rows = (count + cols - 1) / cols;
            int cell_width = (usable_width - (cols - 1) * GAPS) / cols;
            int cell_height = (usable_height - (rows - 1) * GAPS) / rows;
            
            for (i = 0; i < count; i++) {
                int col = i % cols;
                int row = i / cols;
                int x = start_x + col * (cell_width + GAPS);
                int y = start_y + row * (cell_height + GAPS);
                apply_window_position(windows[i], x, y, cell_width, cell_height);
            }
            break;
        }
        
        case MASTER: {
            int master_count = (count > 1) ? 1 : 0;
            int stack_count = count - master_count;
            
            if (master_count > 0) {
                int master_width = (usable_width * MASTER_WIDTH_RATIO / 100) - GAPS/2;
                apply_window_position(windows[0], start_x, start_y, 
                                     master_width, usable_height);
                
                if (stack_count > 0) {
                    int stack_width = usable_width - master_width - GAPS;
                    int stack_height = usable_height / stack_count;
                    
                    for (i = 0; i < stack_count; i++) {
                        int x = start_x + master_width + GAPS;
                        int y = start_y + i * stack_height;
                        if (i > 0) y += GAPS;
                        apply_window_position(windows[i+1], x, y, 
                                             stack_width, stack_height - (i>0?GAPS:0));
                    }
                }
            } else {
                apply_window_position(windows[0], start_x, start_y, 
                                     usable_width, usable_height);
            }
            break;
        }
        
        case ROWS: {
            int row_height = (usable_height - (count - 1) * GAPS) / count;
            
            for (i = 0; i < count; i++) {
                int y = start_y + i * (row_height + GAPS);
                apply_window_position(windows[i], start_x, y, 
                                     usable_width, row_height);
            }
            break;
        }
        
        case COLS: {
            int col_width = (usable_width - (count - 1) * GAPS) / count;
            
            for (i = 0; i < count; i++) {
                int x = start_x + i * (col_width + GAPS);
                apply_window_position(windows[i], x, start_y, 
                                     col_width, usable_height);
            }
            break;
        }
    }
    
    free(windows);
}

void tile_windows(ScreenInfo *s)
{
    tile_windows_layout(s, DEFAULT_TILE_LAYOUT);
}
