/* Copyright (c) 1994-1996 David Hogan, see README for licence details */
#include <X11/extensions/shape.h>
#ifdef	DEBUG
#define	trace(s, c, e)	dotrace((s), (c), (e))
#else
#define	trace(s, c, e)
#endif

#define setstate setstate5element

unsigned long colorpixel(Display*, ScreenInfo*, int, unsigned long, unsigned long);

void	usage(void);
void	initscreen(ScreenInfo*, int);
ScreenInfo *getscreen(Window);
Time	timestamp(void);
void	sendcmessage(Window, Atom, long, int, int);
void	sendconfig(Client*);
void	sighandler(int);
void	getevent(XEvent*);
void	cleanup(void);

void	mainloop(int);
void	configurereq(XConfigureRequestEvent*);
void	mapreq(XMapRequestEvent*);
void	circulatereq(XCirculateRequestEvent*);
void	unmap(XUnmapEvent*);
void	newwindow(XCreateWindowEvent*);
void	destroy(Window);
void	clientmesg(XClientMessageEvent*);
void	cmap(XColormapEvent*);
void	property(XPropertyEvent*);
void	shapenotify(XShapeEvent*);
void	enter(XCrossingEvent*);
void	leave(XCrossingEvent*);
void	focusin(XFocusChangeEvent*);
void	reparent(XReparentEvent*);
void 	motionnotify(XMotionEvent*);
BorderOrient borderorient(Client*, int, int);

int 	manage(Client*, int);
void	scanwins(ScreenInfo*);
void	setshape(Client*);
void	withdraw(Client*);
void	gravitate(Client*);
void	cmapfocus(Client*);
void	cmapnofocus(ScreenInfo*);
void	getcmaps(Client*);
int 	_getprop(Window, Atom, Atom, long, unsigned char**);
char	*getprop(Window, Atom);
Window	getwprop(Window, Atom);
int 	getiprop(Window, Atom);
int 	getstate(Window, int*);
void	setstate(Client*, int);
void	setlabel(Client*);
void	getproto(Client*);
void	gettrans(Client*);

void keypress(XKeyEvent*);
void keyrelease(XKeyEvent*);
void keysetup(void);

void	button(XButtonEvent*);
void	spawn(ScreenInfo*);
void	reshape(Client*, int, int (*)(Client*, int, XButtonEvent*), XButtonEvent*);
void	move(Client*, int);
void	delete(Client*, int);
void	hide(Client*);
void	unhide(int, int);
void	unhidec(Client*, int);
void	renamec(Client*, char*);

void	setactive(Client*, int);
void	draw_border(Client*, int);
void	active(Client*);
void	nofocus(void);
void	top(Client*);
Client	*getclient(Window, int);
void	rmclient(Client*);
void	dump_revert(void);
void	dump_clients(void);
void shuffle(int);

int 	menuhit(XButtonEvent*, Menu*);
Client	*selectwin(int, int*, ScreenInfo*);
int 	sweep(Client*, int, XButtonEvent*);
int 	drag(Client*, int);
int 	pull(Client*, int, XButtonEvent*);
void	getmouse(int*, int*, ScreenInfo*);
void	setmouse(int, int, ScreenInfo*);

int 	handler(Display*, XErrorEvent*);
void	fatal(char*);
void	graberror(char*, int);
void	showhints(Client*);

void	initcurs(ScreenInfo*);

void ShowEvent(XEvent*);

extern int requirePosition;
void spawn_prompt(ScreenInfo *);
void spawn_terminal(ScreenInfo *);
void init_ewmh(void);
void tile_windows(ScreenInfo *s);
void tile_windows_layout(ScreenInfo *s, int layout);
void handle_custom_keypress(XKeyEvent *e, ScreenInfo *s);

/* Scrollable viewport functions */
void scroll_viewport(ScreenInfo *s, int delta_x, int delta_y);
void apply_scroll_to_windows(ScreenInfo *s);
int get_screen_x(ScreenInfo *s, int world_x);
int get_screen_y(ScreenInfo *s, int world_y);
int get_world_x(ScreenInfo *s, int screen_x);
int get_world_y(ScreenInfo *s, int screen_y);

/* Camera centering functions */
void center_camera_on_origin(ScreenInfo *s);
void center_camera_on_window(Client *c);
void center_camera_on_current(void);

/* Title bar functions */
void draw_title(Client *c, int active);
int intitle(Client *c, int x, int y);
int inclosebutton(Client *c, int x, int y);

void motion_handler(XEvent *e);
