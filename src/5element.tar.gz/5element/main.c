/* Copyright (c) 1994-1996 David Hogan, see README for licence details */
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <X11/X.h>
#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/extensions/shape.h>
#include <sys/wait.h>
#include "dat.h"
#include "fns.h"
#include "patchlevel.h"
#include "config.h"

char	*version[] =
{
	"5element, rio fork with scrollable viewport, version 1.0", 0
};

Display 		*dpy;
ScreenInfo	*screens;
int 			initting;
XFontStruct 	*font;
XFontStruct 	*title_font;
XFontStruct 	*menu_font;
char			**myargv;
char			*shell;
Bool			shape;
int 			_corner = 25;
int 			_inset = 1;
int 			curtime;
int 			debug;
int 			signalled;
int 			num_screens;
int			solidsweep = 0;
int			ffm = FFM;

Atom		exit_5element;
Atom		restart_5element;
Atom		wm_state;
Atom		wm_change_state;
Atom		wm_protocols;
Atom		wm_delete;
Atom		wm_take_focus;
Atom		wm_colormaps;
Atom		_5element_running;
Atom		wm_state_fullscreen;

char	*fontlist[] = {
    "lucm.latin1.9",
	"blit",
	"*-lucidatypewriter-bold-*-14-*-75-*",
	"*-lucidatypewriter-medium-*-12-*-75-*",
	"9x15bold",
	"fixed",
	"*",
	0
};

void
usage(void)
{
	fprintf(stderr, "usage: 5element [-version] [exit|restart]\n");
	exit(1);
}

int
main(int argc, char *argv[])
{
	int i, do_exit, do_restart;
	char *fname;
	int shape_event;
#ifdef SHAPE
	int dummy;
#endif

	shape_event = 0;
	myargv = argv;

	do_exit = do_restart = 0;
	font = 0;
	fname = 0;
	for(i = 1; i < argc; i++)
		if(strcmp(argv[i], "-debug") == 0)
			debug++;
        else if(strcmp(argv[i], "-version") == 0){
			fprintf(stderr, "%s", version[0]);
			if(PATCHLEVEL > 0)
				fprintf(stderr, "; patch level %d", PATCHLEVEL);
			fprintf(stderr, "\n");
			exit(0);
		}
		else if(argv[i][0] == '-')
			usage();
		else
			break;
	for(; i < argc; i++)
		if(strcmp(argv[i], "exit") == 0)
			do_exit++;
		else if(strcmp(argv[i], "restart") == 0)
			do_restart++;
		else
			usage();

	if(do_exit && do_restart)
		usage();

	shell = (char *)getenv("SHELL");
	if(shell == NULL)
		shell = DEFSHELL;

	dpy = XOpenDisplay("");
	if(dpy == 0)
		fatal("can't open display");

	initting = 1;
	XSetErrorHandler(handler);
	signal(SIGTERM, SIG_DFL);
	signal(SIGINT, SIG_DFL);
	signal(SIGHUP, SIG_DFL);

	exit_5element = XInternAtom(dpy, "9WM_EXIT", False);
	restart_5element = XInternAtom(dpy, "9WM_RESTART", False);

	curtime = -1;
	if(do_exit){
		sendcmessage(DefaultRootWindow(dpy), exit_5element, 0L, 1, 1);
		XSync(dpy, False);
		cleanup();
		exit(0);
	}
	if(do_restart){
		sendcmessage(DefaultRootWindow(dpy), restart_5element, 0L, 1, 1);
		XSync(dpy, False);
		cleanup();
		exit(0);
	}

	wm_state = XInternAtom(dpy, "WM_STATE", False);
	wm_change_state = XInternAtom(dpy, "WM_CHANGE_STATE", False);
	wm_protocols = XInternAtom(dpy, "WM_PROTOCOLS", False);
	wm_delete = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
	wm_take_focus = XInternAtom(dpy, "WM_TAKE_FOCUS", False);
	wm_colormaps = XInternAtom(dpy, "WM_COLORMAP_WINDOWS", False);
	_5element_running = XInternAtom(dpy, "_9WM_RUNNING", False);
	wm_state = XInternAtom(dpy, "_NET_WM_STATE", False);
	wm_state_fullscreen = XInternAtom(dpy, "_NET_WM_STATE_FULLSCREEN", False);

	if(font == 0){
		i = 0;
		for(;;){
			fname = fontlist[i++];
			if(fname == 0){
				fprintf(stderr, "5element: warning: can't find a font\n");
				break;
			}
			font = XLoadQueryFont(dpy, fname);
			if(font != 0) {
				break;
			}
		}
	}

	title_font = XLoadQueryFont(dpy, TITLE_FONT);
	if(title_font == 0){
		fprintf(stderr, "5element: warning: can't load title font '%s', falling back\n", TITLE_FONT);
		title_font = font;
	}

	menu_font = XLoadQueryFont(dpy, MENU_FONT);
	if(menu_font == 0){
		fprintf(stderr, "5element: warning: can't load menu font '%s', falling back\n", MENU_FONT);
		menu_font = font;
	}

#ifdef	SHAPE
	shape = XShapeQueryExtension(dpy, &shape_event, &dummy);
#endif

	num_screens = ScreenCount(dpy);
	screens = (ScreenInfo *)malloc(sizeof(ScreenInfo) * num_screens);
	if (!screens) {
		fatal("out of memory");
	}

	for(i = 0; i < num_screens; i++)
		initscreen(&screens[i], i);

	curtime = CurrentTime;
	XSetSelectionOwner(dpy, _5element_running, screens[0].menuwin, timestamp());

	XSync(dpy, False);
	initting = 0;

    init_ewmh();
	autostart();
	nofocus();

	for(i = 0; i < num_screens; i++)
		scanwins(&screens[i]);

	keysetup();
	initdynmenu();

	mainloop(shape_event);
	return 0;
}

void
initscreen(ScreenInfo *s, int i)
{
    char *ds, *colon, *dot1;
    unsigned long mask;
    unsigned long gmask;
    XGCValues gv;
    XSetWindowAttributes attr;
    XVisualInfo xvi;
    XSetWindowAttributes attrs;

    s->num = i;
    s->root = RootWindow(dpy, i);
    s->def_cmap = DefaultColormap(dpy, i);
    s->min_cmaps = MinCmapsOfScreen(ScreenOfDisplay(dpy, i));
    s->depth = DefaultDepth(dpy, i);
    s->scroll_x = 0;
    s->scroll_y = 0;

    if(XMatchVisualInfo(dpy, i, 16, TrueColor, &xvi)
    || XMatchVisualInfo(dpy, i, 16, DirectColor, &xvi)){
        s->vis = xvi.visual;
        s->depth = 16;
    }
    else
    if(XMatchVisualInfo(dpy, i, 15, TrueColor, &xvi)
    || XMatchVisualInfo(dpy, i, 15, DirectColor, &xvi)){
        s->vis = xvi.visual;
        s->depth = 15;
    }
    else
    if(XMatchVisualInfo(dpy, i, 24, TrueColor, &xvi)
    || XMatchVisualInfo(dpy, i, 24, DirectColor, &xvi)){
        s->vis = xvi.visual;
        s->depth = 24;
    }
    else
    if(XMatchVisualInfo(dpy, i, 8, PseudoColor, &xvi)
    || XMatchVisualInfo(dpy, i, 8, StaticColor, &xvi)){
        s->vis = xvi.visual;
        s->depth = 8;
    }
    else{
        s->depth = DefaultDepth(dpy, i);
        if(s->depth != 8){
            fprintf(stderr, "can't understand depth %d screen", s->depth);
            exit(1);
        }
        s->vis = DefaultVisual(dpy, i);
    }
    if(DefaultDepth(dpy, i) != s->depth)
        s->def_cmap = XCreateColormap(dpy, s->root, s->vis, AllocNone); 

    ds = DisplayString(dpy);
    colon = rindex(ds, ':');
    if(colon && num_screens > 1){
        strcpy(s->display, "DISPLAY=");
        strcat(s->display, ds);
        colon = s->display + 8 + (colon - ds);
        dot1 = index(colon, '.');
        if(dot1)
            sprintf(dot1+1, "%d", i);
        else
            sprintf(colon+strlen(colon), ".%d", i);
    } else
        s->display[0] = '\0';

    s->black = BlackPixel(dpy, i);
    s->white = WhitePixel(dpy, i);

    s->activeborder = colorpixel(dpy, s, s->depth, ACTIVE_BORDER_COLOR, s->black);
    s->inactiveborder = colorpixel(dpy, s, s->depth, INACTIVE_BORDER_COLOR, s->black);
    s->activeborder2 = colorpixel(dpy, s, s->depth, ACTIVE_INNER_BORDER_COLOR, s->white);
    s->inactiveborder2 = colorpixel(dpy, s, s->depth, INACTIVE_INNER_BORDER_COLOR, s->white);
    
    s->width = WidthOfScreen(ScreenOfDisplay(dpy, i));
    s->height = HeightOfScreen(ScreenOfDisplay(dpy, i));
    s->bkup[0] = XCreatePixmap(dpy, s->root, 2*s->width, 1, s->depth);
    s->bkup[1] = XCreatePixmap(dpy, s->root, 1, 2*s->height, s->depth);

	gv.foreground = s->black^s->white;
	gv.background = s->white;
	gv.function = GXxor;
	gv.line_width = 0;
	gv.subwindow_mode = IncludeInferiors;
	gmask = GCForeground | GCBackground | GCFunction | GCLineWidth | GCSubwindowMode;
	if(font != 0){
		gv.font = font->fid;
		gmask |= GCFont;
	}
	s->gc = XCreateGC(dpy, s->root, gmask, &gv);

	gv.function = GXcopy;
	s->gccopy = XCreateGC(dpy, s->root, gmask, &gv);
	s->gcred = XCreateGC(dpy, s->root, gmask, &gv);

	gv.foreground = colorpixel(dpy, s, s->depth, 0xEEEEEE, s->black);
	s->gcsweep = XCreateGC(dpy, s->root, gmask, &gv);

    initcurs(s);

    attr.cursor = s->arrow;
    attr.event_mask = SubstructureRedirectMask
        | SubstructureNotifyMask | ColormapChangeMask
        | ButtonPressMask | ButtonReleaseMask | PropertyChangeMask 
        | KeyPressMask | EnterWindowMask | PointerMotionMask;
    mask = CWCursor|CWEventMask;
    XChangeWindowAttributes(dpy, s->root, mask, &attr);
    XSync(dpy, False);

    attrs.border_pixel = colorpixel(dpy, s, s->depth, MENU_BORDER_COLOR, s->black);
    attrs.background_pixel = colorpixel(dpy, s, s->depth, MENU_BACKGROUND_COLOR, s->black);
    attrs.colormap = s->def_cmap;

    s->menuwin = XCreateWindow(dpy, s->root, 0, 0, 1, 1, 2,
                        s->depth, CopyFromParent, s->vis,
                        CWBackPixel | CWBorderPixel | CWColormap, &attrs);

    gv.foreground = colorpixel(dpy, s, s->depth, MENU_BACKGROUND_COLOR, s->black);
    gv.function = GXcopy;
    if(menu_font != 0){
        gv.font = menu_font->fid;
        gmask |= GCFont;
    }
    s->gcmenubg = XCreateGC(dpy, s->menuwin, gmask, &gv);

    gv.foreground = colorpixel(dpy, s, s->depth, MENU_ACTIVE_BACKGROUND_COLOR, s->white);
    s->gcmenubgs = XCreateGC(dpy, s->menuwin, gmask, &gv);

    gv.foreground = colorpixel(dpy, s, s->depth, MENU_TEXT_COLOR, s->black);
    gv.background = colorpixel(dpy, s, s->depth, MENU_BACKGROUND_COLOR, s->black);
    s->gcmenufg = XCreateGC(dpy, s->menuwin, gmask, &gv);

    gv.foreground = colorpixel(dpy, s, s->depth, MENU_BACKGROUND_COLOR, s->black);
    gv.background = s->activeborder;
    s->gcmenufgs = XCreateGC(dpy, s->menuwin, gmask, &gv);

    attrs.override_redirect = True;
    s->sweepwin = XCreateWindow(dpy, s->root, 0, 0, 1, 1, 0,
                        0, InputOnly, CopyFromParent, CWOverrideRedirect, &attrs);
}

ScreenInfo*
getscreen(Window w)
{
	int i;

	for(i = 0; i < num_screens; i++)
		if(screens[i].root == w)
			return &screens[i];

	return 0;
}

Time
timestamp(void)
{
	XEvent ev;

	if(curtime == CurrentTime){
		XChangeProperty(dpy, screens[0].root, _5element_running, _5element_running, 8,
				PropModeAppend, (unsigned char *)"", 0);
		XMaskEvent(dpy, PropertyChangeMask, &ev);
		curtime = ev.xproperty.time;
	}
	return curtime;
}

void
sendcmessage(Window w, Atom a, long x, int isroot, int usemask)
{
	XEvent ev;
	int status;
	long mask;

	memset(&ev, 0, sizeof(ev));
	ev.xclient.type = ClientMessage;
	ev.xclient.window = w;
	ev.xclient.message_type = a;
	ev.xclient.format = 32;
	ev.xclient.data.l[0] = x;
	ev.xclient.data.l[1] = timestamp();
	mask = 0;
	if(usemask){
		mask |= KeyPressMask;
		if(isroot)
			mask |= SubstructureRedirectMask;
		else
			mask |= ExposureMask;
	}
	status = XSendEvent(dpy, w, False, mask, &ev);
	if(status == 0)
		fprintf(stderr, "5element: sendcmessage failed\n");
}

void
sendconfig(Client *c)
{
	XConfigureEvent ce;

	ce.type = ConfigureNotify;
	ce.event = c->window;
	ce.window = c->window;
	ce.x = INNER_BORDER; 
	ce.y = INNER_BORDER;
	ce.width = c->dx;
	ce.height = c->dy;
	ce.border_width = 0;
	ce.above = None;
	ce.override_redirect = False;

	XSendEvent(dpy, c->window, False, StructureNotifyMask, (XEvent*)&ce);
}

void
sighandler(int sig)
{
	signalled = 1;
}

void
getevent(XEvent *e)
{
    int fd;
    fd_set rfds;
    struct timeval t;

    if(!signalled){
        if(QLength(dpy) > 0){
            XNextEvent(dpy, e);
            return;
        }
        fd = ConnectionNumber(dpy);
        FD_ZERO(&rfds);
        FD_SET(fd, &rfds);
        t.tv_sec = 0;
        t.tv_usec = 10000;
        
        if(select(fd+1, &rfds, NULL, NULL, &t) == 1){
            XNextEvent(dpy, e);
            return;
        }
        
        extern int panning;
        if(panning) {
            if(XCheckMaskEvent(dpy, PointerMotionMask, e)) {
                if(e->type == MotionNotify)
                    motion_handler(e);
            }
            return;
        }
        
        XFlush(dpy);
        FD_SET(fd, &rfds);
        if(select(fd+1, &rfds, NULL, NULL, NULL) == 1){
            XNextEvent(dpy, e);
            return;
        }
        if(errno != EINTR || !signalled){
            perror("5element: select failed");
            exit(1);
        }
    }
    fprintf(stderr, "5element: exiting on signal\n");
    cleanup();
    exit(1);
}

void
motion_handler(XEvent *e)
{
    XMotionEvent *me = (XMotionEvent*)e;
    extern int panning;
    extern int pan_start_x, pan_start_y;
    extern int pan_start_scroll_x, pan_start_scroll_y;
    ScreenInfo *s;
    static struct timeval last_update = {0, 0};
    struct timeval now, diff;
    long elapsed_us;
    long min_interval_us = 1000000 / REFRESHRATE;
    
    if(!panning)
        return;
        
    s = getscreen(me->root);
    if(!s)
        return;
    
    gettimeofday(&now, NULL);
    
    if(last_update.tv_sec != 0 || last_update.tv_usec != 0) {
        timersub(&now, &last_update, &diff);
        elapsed_us = diff.tv_sec * 1000000 + diff.tv_usec;
        if(elapsed_us < min_interval_us)
            return;
    }
    
    last_update = now;
        
    int dx = pan_start_x - me->x_root;
    int dy = pan_start_y - me->y_root;
    
    s->scroll_x = pan_start_scroll_x + dx;
    s->scroll_y = pan_start_scroll_y + dy;
    
    if(s->scroll_x < 0) s->scroll_x = 0;
    if(s->scroll_y < 0) s->scroll_y = 0;
    
    apply_scroll_to_windows(s);
}

void
cleanup(void)
{
	static int cleaned = 0;
	if(cleaned)
		return;
	cleaned = 1;
	if(dpy){
		XSetInputFocus(dpy, PointerRoot, RevertToPointerRoot, timestamp());
		for(int i = 0; i < num_screens; i++)
			cmapnofocus(&screens[i]);
		XCloseDisplay(dpy);
	}
	if(screens)
		free(screens);
}

void
init_ewmh(void)
{
	Atom net_wm_name = XInternAtom(dpy, "_NET_WM_NAME", False);
	Atom utf8_string = XInternAtom(dpy, "UTF8_STRING", False);
	Atom net_supporting_wm_check = XInternAtom(dpy, "_NET_SUPPORTING_WM_CHECK", False);

	char wm_name[] = "5element";

	XChangeProperty(dpy, DefaultRootWindow(dpy), net_wm_name, utf8_string, 8,
					PropModeReplace, (unsigned char *)wm_name, strlen(wm_name));

	Window wm_check_window = XCreateSimpleWindow(dpy, DefaultRootWindow(dpy), 0, 0, 1, 1, 0, 0, 0);
	XChangeProperty(dpy, DefaultRootWindow(dpy), net_supporting_wm_check,
					XA_WINDOW, 32, PropModeReplace, (unsigned char *)&wm_check_window, 1);
	XChangeProperty(dpy, wm_check_window, net_supporting_wm_check,
					XA_WINDOW, 32, PropModeReplace, (unsigned char *)&wm_check_window, 1);
	XChangeProperty(dpy, wm_check_window, net_wm_name, utf8_string, 8,
					PropModeReplace, (unsigned char *)wm_name, strlen(wm_name));
}

void
autostart(void)
{
    const char *progs[] = { AUTOSTART_PROGRAMS };
    int i;
    pid_t pid;

    for(i = 0; i < sizeof(progs)/sizeof(progs[0]); i++) {
        pid = fork();
        if(pid == 0) {
            /* Child process */
            setsid();
            /* Fork again to detach */
            if(fork() == 0) {
                /* Set DISPLAY */
                char display[32];
                snprintf(display, sizeof(display), "DISPLAY=%s", DisplayString(dpy));
                putenv(display);
                /* Execute program */
                execlp("/bin/sh", "sh", "-c", progs[i], NULL);
                exit(1);
            }
            exit(0);
        } else if(pid > 0) {
            /* Parent waits for first child */
            waitpid(pid, NULL, 0);
        }
        usleep(500000); /* 0.5 sec delay between starts */
    }
}
