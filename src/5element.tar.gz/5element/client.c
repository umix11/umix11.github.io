/* Copyright (c) 1994-1996 David Hogan, see README for licence details */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "dat.h"
#include "fns.h"
#include "config.h"

Client	*clients;
Client	*current;

/* Panning globals */
int panning = 0;
int pan_start_x = 0;
int pan_start_y = 0;
int pan_start_scroll_x = 0;
int pan_start_scroll_y = 0;

/* Throttling globals */
static struct timeval last_pan_time = {0, 0};
static long frame_interval_us = 0;

void
setactive(Client *c, int on)
{
	if(c->parent == c->screen->root)
		return;
	
	if(on){
		XUngrabButton(dpy, AnyButton, AnyModifier, c->parent2);
		XSetInputFocus(dpy, c->window, RevertToPointerRoot, timestamp());
		if(c->proto & Ptakefocus)
			sendcmessage(c->window, wm_protocols, wm_take_focus, 0, 1);
		cmapfocus(c);
	}else{
		XGrabButton(dpy, AnyButton, AnyModifier, c->parent2, False,
			ButtonMask, GrabModeAsync, GrabModeSync, None, None);
	}
	draw_border(c, on);
}

void
draw_border(Client *c, int active)
{
	unsigned long pixel, pixel2;

	if(active){
		pixel = c->screen->activeborder;
		pixel2 = c->screen->activeborder2;
	}else{
		pixel = c->screen->inactiveborder;
		pixel2 = c->screen->inactiveborder2;
	}

	XSetWindowBackground(dpy, c->parent, pixel);
	XClearWindow(dpy, c->parent);
	XSetWindowBackground(dpy, c->parent2, pixel2);
	XClearWindow(dpy, c->parent2);
	
#if TITLEBARS
	draw_title(c, active);
#endif
}

void
active(Client *c)
{
	Client *cc;

	if(c == 0){
		fprintf(stderr, "5element: active(c==0)\n");
		return;
	}
	if(c == current)
		return;
	if(current){
		setactive(current, 0);
		if(current->screen != c->screen)
			cmapnofocus(current->screen);
	}
	setactive(c, 1);
	for(cc = clients; cc; cc = cc->next)
		if(cc->revert == c)
			cc->revert = c->revert;
	c->revert = current;
	while(c->revert && !normal(c->revert))
		c->revert = c->revert->revert;
	current = c;

#ifdef	DEBUG
	if(debug)
		dump_revert();
#endif
}

void
nofocus(void)
{
	static Window w = 0;
	int mask;
	XSetWindowAttributes attr;
	Client *c;

	if(current){
		setactive(current, 0);
		for(c = current->revert; c; c = c->revert)
			if(normal(c)){
				active(c);
				return;
			}
		cmapnofocus(current->screen);
	}
	current = 0;
	if(w == 0){
		mask = CWOverrideRedirect;
		attr.override_redirect = 1;
		w = XCreateWindow(dpy, screens[0].root, 0, 0, 1, 1, 0,
			0, InputOnly, 	screens[0].vis, mask, &attr);
		XMapWindow(dpy, w);
	}
	XSetInputFocus(dpy, w, RevertToPointerRoot, timestamp());
}

void
top(Client *c)
{
	Client **l, *cc;

	l = &clients;
	for(cc = *l; cc; cc = *l){
		if(cc == c){
			*l = c->next;
			c->next = clients;
			clients = c;
			return;
		}
		l = &cc->next;
	}
	fprintf(stderr, "5element: %p not on client list in top()\n", (void*)c);
}

Client *
getclient(Window w, int create)
{
	Client *c;

	if(w == 0 || getscreen(w))
		return 0;

	for(c = clients; c; c = c->next)
		if(c->window == w || c->parent == w || c->parent2 == w)
			return c;

	if(!create)
		return 0;

	c = (Client *)malloc(sizeof(Client));
	memset(c, 0, sizeof(Client));
	c->window = w;
	c->parent = None;
	c->parent2 = None;
	c->reparenting = 0;
	c->state = WithdrawnState;
	c->init = 0;
	c->cmap = None;
	c->label = c->class = 0;
	c->revert = 0;
	c->is9term = 0;
	c->ncmapwins = 0;
	c->cmapwins = 0;
	c->wmcmaps = 0;
	c->next = clients;
	c->sticky = 0;
	clients = c;
	return c;
}

void
rmclient(Client *c)
{
	Client *cc;

	for(cc = current; cc && cc->revert; cc = cc->revert)
		if(cc->revert == c)
			cc->revert = cc->revert->revert;

	if(c == clients)
		clients = c->next;
	for(cc = clients; cc && cc->next; cc = cc->next)
		if(cc->next == c)
			cc->next = cc->next->next;

	if(hidden(c))
		unhidec(c, 0);

	if(c->parent2 != None && c->parent2 != c->screen->root)
		XDestroyWindow(dpy, c->parent2);
	if(c->parent != None && c->parent != c->screen->root)
		XDestroyWindow(dpy, c->parent);

	c->parent2 = c->parent = c->window = None;
	if(current == c){
		current = c->revert;
		if(current == 0)
			nofocus();
		else {
			if(current->screen != c->screen)
				cmapnofocus(c->screen);
			setactive(current, 1);
		}
	}
	if(c->ncmapwins != 0){
		XFree((char *)c->cmapwins);
		free((char *)c->wmcmaps);
	}
	if(c->iconname != 0)
		XFree((char*) c->iconname);
	if(c->name != 0)
		XFree((char*) c->name);
	if(c->instance != 0)
		XFree((char*) c->instance);
	if(c->class != 0)
		XFree((char*) c->class);
	memset(c, 0, sizeof(Client));
	free(c);
}

#ifdef	DEBUG
void
dump_revert(void)
{
	Client *c;
	int i;

	i = 0;
	for(c = current; c; c = c->revert){
		fprintf(stderr, "%s(%x:%d)", c->label ? c->label : "?", (int)c->window, c->state);
		if(i++ > 100)
			break;
		if(c->revert)
			fprintf(stderr, " -> ");
	}
	if(current == 0)
		fprintf(stderr, "empty");
	fprintf(stderr, "\n");
}

void
dump_clients(void)
{
	Client *c;

	for(c = clients; c; c = c->next)
		fprintf(stderr, "w 0x%x parent 0x%x @ (%d, %d)\n", (int)c->window, (int)c->parent, c->x, c->y);
}
#endif

void
shuffle(int up)
{
	Client **l, *c;
	
	if(clients == 0 || clients->next == 0)
		return;
	if(!up){
		c = 0;
		for(l=&clients; (*l)->next; l=&(*l)->next)
			if ((*l)->state == 1)
				c = *l;
		if (c == 0)
			return;
		XMapRaised(dpy, c->parent2);
		top(c);
		active(c);
	}else{
		c = clients;
		for(l=&clients; *l; l=&(*l)->next)
			;
		clients = c->next;
		*l = c;
		c->next = 0;
		XLowerWindow(dpy, c->window);
	}
}

/* Scrollable viewport functions */

int
get_screen_x(ScreenInfo *s, int world_x)
{
	return world_x - s->scroll_x;
}

int
get_screen_y(ScreenInfo *s, int world_y)
{
	return world_y - s->scroll_y;
}

int
get_world_x(ScreenInfo *s, int screen_x)
{
	return screen_x + s->scroll_x;
}

int
get_world_y(ScreenInfo *s, int screen_y)
{
	return screen_y + s->scroll_y;
}

void
scroll_viewport(ScreenInfo *s, int delta_x, int delta_y)
{
	Client *c;
	struct timeval now, diff;
	long elapsed_us;
	
#if TITLEBARS
	int title_offset = TITLEHEIGHT;
#else
	int title_offset = 0;
#endif

	if(frame_interval_us == 0)
		frame_interval_us = 1000000 / REFRESHRATE;
	
	gettimeofday(&now, NULL);
	
	if(last_pan_time.tv_sec != 0 || last_pan_time.tv_usec != 0) {
		timersub(&now, &last_pan_time, &diff);
		elapsed_us = diff.tv_sec * 1000000 + diff.tv_usec;
		if(elapsed_us < frame_interval_us)
			return;
	}
	
	last_pan_time = now;
	
	s->scroll_x += delta_x;
	s->scroll_y += delta_y;
	
	for(c = clients; c; c = c->next) {
		if(c->screen != s)
			continue;
		if(c->sticky)
			continue;
		if(c->parent == c->screen->root)
			continue;
		if(!normal(c))
			continue;
			
		int screen_x = get_screen_x(s, c->x);
		int screen_y = get_screen_y(s, c->y);
		
		XMoveWindow(dpy, c->parent, 
		           screen_x - BORDER, 
		           screen_y - BORDER - title_offset);
	}
	
	XSync(dpy, False);
}

void
apply_scroll_to_windows(ScreenInfo *s)
{
	Client *c;
	int window_count = 0;
	
#if TITLEBARS
	int title_offset = TITLEHEIGHT;
#else
	int title_offset = 0;
#endif
	
	for(c = clients; c; c = c->next) {
		if(c->screen != s)
			continue;
		if(c->sticky)
			continue;
		if(c->parent == c->screen->root)
			continue;
		if(!normal(c))
			continue;
			
		int screen_x = get_screen_x(s, c->x);
		int screen_y = get_screen_y(s, c->y);
		
		XMoveWindow(dpy, c->parent, 
		           screen_x - BORDER, 
		           screen_y - BORDER - title_offset);
		
		window_count++;
	}
	
	if(window_count > 0)
		XSync(dpy, False);
}

/* Camera control functions */

void
center_camera_on_origin(ScreenInfo *s)
{
	if(s == NULL)
		return;
	
	int delta_x = -s->scroll_x;
	int delta_y = -s->scroll_y;
	
	scroll_viewport(s, delta_x, delta_y);
}

void
center_camera_on_window(Client *c)
{
	if(c == NULL || c->screen == NULL)
		return;
	
	ScreenInfo *s = c->screen;
	
	int window_center_x = c->x + c->dx / 2;
	int window_center_y = c->y + c->dy / 2;
	
	int new_scroll_x = window_center_x - s->width / 2;
	int new_scroll_y = window_center_y - s->height / 2;
	
	int delta_x = new_scroll_x - s->scroll_x;
	int delta_y = new_scroll_y - s->scroll_y;
	
	scroll_viewport(s, delta_x, delta_y);
}

void
center_camera_on_current(void)
{
	if(current == NULL)
		return;
	
	center_camera_on_window(current);
}
