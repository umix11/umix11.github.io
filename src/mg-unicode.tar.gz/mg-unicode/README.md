mg code editor with my own patches:

- utf-8 support
- 4 indents on tabs by default
- no backup files by default
- coping to clipboard support(requires xclip)
- line numbers (can be disabled in display.c)
- statusbar can be disabled (in display.c too)
