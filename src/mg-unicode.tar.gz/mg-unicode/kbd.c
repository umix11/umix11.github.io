/*	$OpenBSD: kbd.c,v 1.30 2015/09/26 21:51:58 jasper Exp $	*/

/* This file is in the public domain. */

/*
 *	Terminal independent keyboard handling with UTF-8 support.
 */

#include <ctype.h>
#include <limits.h>
#include <sys/queue.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

#include "def.h"
#include "kbd.h"
#include "key.h"
#include "macro.h"

#define METABIT 0x80

#define PROMPTL 80
char	 prompt[PROMPTL] = "", *promptp = prompt;

static int mgwrap(PF, int, int);

static int	 use_metakey = TRUE;
static int	 pushed = FALSE;
static int	 pushedc;

struct map_element	*ele;

struct key key;

/* UTF-8 helper functions */
static int
utf8_nbytes(unsigned char c)
{
	if ((c & 0x80) == 0x00)
		return 1;  /* 0xxxxxxx - ASCII */
	if ((c & 0xE0) == 0xC0)
		return 2;  /* 110xxxxx - 2 bytes */
	if ((c & 0xF0) == 0xE0)
		return 3;  /* 1110xxxx - 3 bytes */
	if ((c & 0xF8) == 0xF0)
		return 4;  /* 11110xxx - 4 bytes */
	return 1;      /* Invalid, treat as single byte */
}

/*
 * Toggle the value of use_metakey
 */
int
do_meta(int f, int n)
{
	if (f & FFARG)
		use_metakey = n > 0;
	else
		use_metakey = !use_metakey;
	ewprintf("Meta keys %sabled", use_metakey ? "en" : "dis");
	return (TRUE);
}

static int	 bs_map = 0;

/*
 * Toggle backspace mapping
 */
int
bsmap(int f, int n)
{
	if (f & FFARG)
		bs_map = n > 0;
	else
		bs_map = !bs_map;
	ewprintf("Backspace mapping %sabled", bs_map ? "en" : "dis");
	return (TRUE);
}

void
ungetkey(int c)
{
	if (use_metakey && pushed && c == CCHR('['))
		pushedc |= METABIT;
	else
		pushedc = c;
	pushed = TRUE;
}

int
getkey(int flag)
{
	int	 c;
	int	 is_utf8_lead;

	if (flag && !pushed) {
		if (prompt[0] != '\0' && ttwait(2000)) {
			/* avoid problems with % */
			ewprintf("%s", prompt);
			/* put the cursor back */
			update(CMODE);
			epresf = KCLEAR;
		}
		if (promptp > prompt)
			*(promptp - 1) = ' ';
	}
	if (pushed) {
		c = pushedc;
		pushed = FALSE;
	} else
		c = ttgetc();

	if (bs_map) {
		if (c == CCHR('H'))
			c = CCHR('?');
		else if (c == CCHR('?'))
			c = CCHR('H');
	}
	
	/* Check if this is UTF-8 lead byte (0xC0-0xFF), not just METABIT (0x80-0xFF) */
	/* UTF-8 lead bytes: 11xxxxxx (0xC0 and higher) */
	/* UTF-8 continuation bytes and high ASCII: 10xxxxxx or 1000000x */
	is_utf8_lead = ((unsigned char)c >= 0xC0);
	
	/* Only treat as meta-key if metakey is enabled AND it's not UTF-8 lead byte */
	if (use_metakey && (c & METABIT) && !is_utf8_lead) {
		pushedc = c & ~METABIT;
		pushed = TRUE;
		c = CCHR('[');
	}
	if (flag && promptp < &prompt[PROMPTL - 5]) {
		promptp = getkeyname(promptp,
		    sizeof(prompt) - (promptp - prompt) - 1, c);
		*promptp++ = '-';
		*promptp = '\0';
	}
	return (c);
}

/*
 * doscan scans a keymap for a keyboard character and returns a pointer
 * to the function associated with that character.  Sets ele to the
 * keymap element the keyboard was found in as a side effect.
 */
PF
doscan(KEYMAP *map, int c, KEYMAP **newmap)
{
	struct map_element	*elec = &map->map_element[0];
	struct map_element	*last = &map->map_element[map->map_num];
	PF		 ret;

	while (elec < last && c > elec->k_num)
		elec++;

	/* used by prefix and binding code */
	ele = elec;
	if (elec >= last || c < elec->k_base)
		ret = map->map_default;
	else
		ret = elec->k_funcp[c - elec->k_base];
	if (ret == NULL && newmap != NULL)
		*newmap = elec->k_prefmap;

	return (ret);
}

int
doin(void)
{
	KEYMAP	*curmap;
	PF	 funct;
	int	 c;
	int	 i;

	*(promptp = prompt) = '\0';
	curmap = curbp->b_modes[curbp->b_nmodes]->p_map;
	key.k_count = 0;
	
	/* Get first character */
	c = getkey(TRUE);
	key.k_chars[key.k_count++] = c;
	
	/* Check if this is a UTF-8 multibyte sequence start (high bit set) */
	if (c & 0x80) {
		int utf8_len = utf8_nbytes((unsigned char)c);
		
		/* Read remaining UTF-8 bytes directly without going through getkey */
		for (i = 1; i < utf8_len; i++) {
			key.k_chars[key.k_count++] = ttgetc() & 0xFF;
		}
		
		/* For UTF-8 sequences, always use selfinsert */
		funct = selfinsert;
	} else {
		/* Normal ASCII key processing through keymap */
		while ((funct = doscan(curmap, c, &curmap)) == NULL) {
			key.k_chars[key.k_count++] = c = getkey(TRUE);
		}
	}

	if (macrodef && macrocount < MAXMACRO)
		macro[macrocount++].m_funct = funct;

	return (mgwrap(funct, 0, 1));
}

int
rescan(int f, int n)
{
	int	 c;
	KEYMAP	*curmap;
	int	 i;
	PF	 fp = NULL;
	int	 md = curbp->b_nmodes;

	for (;;) {
		if (isupper(key.k_chars[key.k_count - 1])) {
			c = tolower(key.k_chars[key.k_count - 1]);
			curmap = curbp->b_modes[md]->p_map;
			for (i = 0; i < key.k_count - 1; i++) {
				if ((fp = doscan(curmap, (key.k_chars[i]),
				    &curmap)) != NULL)
					break;
			}
			if (fp == NULL) {
				if ((fp = doscan(curmap, c, NULL)) == NULL)
					while ((fp = doscan(curmap,
					    key.k_chars[key.k_count++] =
					    getkey(TRUE), &curmap)) == NULL)
						/* nothing */;
				if (fp != rescan) {
					if (macrodef && macrocount <= MAXMACRO)
						macro[macrocount - 1].m_funct
						    = fp;
					return (mgwrap(fp, f, n));
				}
			}
		}
		/* try previous mode */
		if (--md < 0)
			return (ABORT);
		curmap = curbp->b_modes[md]->p_map;
		for (i = 0; i < key.k_count; i++) {
			if ((fp = doscan(curmap, (key.k_chars[i]), &curmap)) != NULL)
				break;
		}
		if (fp == NULL) {
			while ((fp = doscan(curmap, key.k_chars[i++] =
			    getkey(TRUE), &curmap)) == NULL)
				/* nothing */;
			key.k_count = i;
		}
		if (fp != rescan && i >= key.k_count - 1) {
			if (macrodef && macrocount <= MAXMACRO)
				macro[macrocount - 1].m_funct = fp;
			return (mgwrap(fp, f, n));
		}
	}
}

int
universal_argument(int f, int n)
{
	KEYMAP	*curmap;
	PF	 funct;
	int	 c, nn = 4;

	if (f & FFUNIV)
		nn *= n;
	for (;;) {
		key.k_chars[0] = c = getkey(TRUE);
		key.k_count = 1;
		if (c == '-')
			return (negative_argument(f, nn));
		if (c >= '0' && c <= '9')
			return (digit_argument(f, nn));
		curmap = curbp->b_modes[curbp->b_nmodes]->p_map;
		while ((funct = doscan(curmap, c, &curmap)) == NULL) {
			key.k_chars[key.k_count++] = c = getkey(TRUE);
		}
		if (funct != universal_argument) {
			if (macrodef && macrocount < MAXMACRO - 1) {
				if (f & FFARG)
					macrocount--;
				macro[macrocount++].m_count = nn;
				macro[macrocount++].m_funct = funct;
			}
			return (mgwrap(funct, FFUNIV, nn));
		}
		nn <<= 2;
	}
}

/* ARGSUSED */
int
digit_argument(int f, int n)
{
	KEYMAP	*curmap;
	PF	 funct;
	int	 nn, c;

	nn = key.k_chars[key.k_count - 1] - '0';
	for (;;) {
		c = getkey(TRUE);
		if (c < '0' || c > '9')
			break;
		nn *= 10;
		nn += c - '0';
	}
	key.k_chars[0] = c;
	key.k_count = 1;
	curmap = curbp->b_modes[curbp->b_nmodes]->p_map;
	while ((funct = doscan(curmap, c, &curmap)) == NULL) {
		key.k_chars[key.k_count++] = c = getkey(TRUE);
	}
	if (macrodef && macrocount < MAXMACRO - 1) {
		if (f & FFARG)
			macrocount--;
		else
			macro[macrocount - 1].m_funct = universal_argument;
		macro[macrocount++].m_count = nn;
		macro[macrocount++].m_funct = funct;
	}
	return (mgwrap(funct, FFOTHARG, nn));
}

int
negative_argument(int f, int n)
{
	KEYMAP	*curmap;
	PF	 funct;
	int	 c;
	int	 nn = 0;

	for (;;) {
		c = getkey(TRUE);
		if (c < '0' || c > '9')
			break;
		nn *= 10;
		nn += c - '0';
	}
	if (nn)
		nn = -nn;
	else
		nn = -n;
	key.k_chars[0] = c;
	key.k_count = 1;
	curmap = curbp->b_modes[curbp->b_nmodes]->p_map;
	while ((funct = doscan(curmap, c, &curmap)) == NULL) {
		key.k_chars[key.k_count++] = c = getkey(TRUE);
	}
	if (macrodef && macrocount < MAXMACRO - 1) {
		if (f & FFARG)
			macrocount--;
		else
			macro[macrocount - 1].m_funct = universal_argument;
		macro[macrocount++].m_count = nn;
		macro[macrocount++].m_funct = funct;
	}
	return (mgwrap(funct, FFNEGARG, nn));
}

/*
 * Insert a character. Now with UTF-8 support.
 * All bytes from key.k_chars are inserted.
 */
int
selfinsert(int f, int n)
{
	struct line	*lp;
	int	 count;
	int	 i, j;

	if (n < 0)
		return (FALSE);
	if (n == 0)
		return (TRUE);

	/* Handle newline specially */
	if (key.k_chars[0] == '\n') {
		do {
			count = lnewline();
		} while (--n && count == TRUE);
		return (count);
	}

	if (macrodef && macrocount < MAXMACRO) {
		if (f & FFARG)
			macrocount -= 2;

		/* last command was insert -- tack on the end */
		if (lastflag & CFINS) {
			macrocount--;
			/* Ensure the line can handle the new characters */
			if (maclcur->l_size < maclcur->l_used + n * key.k_count) {
				if (lrealloc(maclcur, maclcur->l_used + n * key.k_count) ==
				    FALSE)
					return (FALSE);
			}
			/* Insert n repetitions of the character sequence */
			for (j = 0; j < n; j++) {
				for (i = 0; i < key.k_count; i++) {
					maclcur->l_text[maclcur->l_used++] = key.k_chars[i];
				}
			}
		} else {
			macro[macrocount - 1].m_funct = insert;
			if ((lp = lalloc(n * key.k_count)) == NULL)
				return (FALSE);
			lp->l_bp = maclcur;
			lp->l_fp = maclcur->l_fp;
			maclcur->l_fp = lp;
			maclcur = lp;
			for (j = 0; j < n; j++) {
				for (i = 0; i < key.k_count; i++) {
					lp->l_text[j * key.k_count + i] = key.k_chars[i];
				}
			}
		}
		thisflag |= CFINS;
	}

	/* overwrite mode */
	if (curbp->b_flag & BFOVERWRITE) {
		lchange(WFEDIT);
		while (curwp->w_doto < llength(curwp->w_dotp) && n--) {
			for (i = 0; i < key.k_count; i++)
				lputc(curwp->w_dotp, curwp->w_doto++, key.k_chars[i]);
		}
		if (n <= 0)
			return (TRUE);
	}
	
	/* Insert all bytes of the character sequence n times */
	for (j = 0; j < n; j++) {
		for (i = 0; i < key.k_count; i++) {
			if (linsert(1, key.k_chars[i]) == FALSE)
				return (FALSE);
		}
	}
	
	return (TRUE);
}

/*
 * This could be implemented as a keymap with everything defined as self-insert.
 */
int
quote(int f, int n)
{
	int	 c;

	key.k_count = 1;
	if ((key.k_chars[0] = getkey(TRUE)) >= '0' && key.k_chars[0] <= '7') {
		key.k_chars[0] -= '0';
		if ((c = getkey(TRUE)) >= '0' && c <= '7') {
			key.k_chars[0] <<= 3;
			key.k_chars[0] += c - '0';
			if ((c = getkey(TRUE)) >= '0' && c <= '7') {
				key.k_chars[0] <<= 3;
				key.k_chars[0] += c - '0';
			} else
				ungetkey(c);
		} else
			ungetkey(c);
	}
	return (selfinsert(f, n));
}

/*
 * Prompt for a codepoint in whatever the native system's encoding is,
 * insert it into the file
 */
int
insert_char(int f, int n)
{
	char *bufp;
	char inpbuf[32];
	wchar_t wc;
	char mb[MB_LEN_MAX];
	mbstate_t mbs = { 0 };
	size_t mbslen;
	size_t i;

	if ((bufp = eread("Insert character (hex): ", inpbuf, sizeof inpbuf,
	     EFNEW)) == NULL) {
		return (ABORT);
	} else if (bufp[0] == '\0') {
		return (FALSE);
	}

	wc = (wchar_t) strtoll(bufp, NULL, 16);
	mbslen = wcrtomb(mb, wc, &mbs);
	if (mbslen == (size_t) -1) {
		return (FALSE);
	}

	for (i = 0; i < mbslen; ++i) {
		if (linsert(1, mb[i]) == FALSE) {
			return (FALSE);
		}
	}

	return (TRUE);
}

/*
 * Wrapper function to count invocation repeats.
 * We ignore any function whose sole purpose is to get us
 * to the intended function.
 */
static int
mgwrap(PF funct, int f, int n)
{
	static	 PF ofp;

	if (funct != rescan &&
	    funct != negative_argument &&
	    funct != digit_argument &&
	    funct != universal_argument) {
		if (funct == ofp)
			rptcount++;
		else
			rptcount = 0;
		ofp = funct;
	}

	return ((*funct)(f, n));
}
